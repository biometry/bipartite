  vaznull <- function(N, web){
  # This function produces a null model network with two constraints:
  # a) marginal totals are only approximately the same as in the original network (in contrast to r2dtable)
  # b) connectance is the same as in the original network.
  # vaznull differs from swap.web both in the algorithm used as well as in the
  # null model it outputs.
  # vaznull is our implementation of the algorithm propose by Diego Vazquez, hence its name.
  #
  # implementor: Bernd Gruber <bernd.gruber@ufz.de> & Carsten Dormann, improvement by Rafael Pinheiro (April 2021)

  web <- as.matrix(empty(web)) # otherwise we cannot compute the crossproduct later on. 

  vaznull.fast <- function(web){
  
  	rs.p <- rowSums(web)/sum(web)
  	cs.p <- colSums(web)/sum(web)
  	P <- P1 <- tcrossprod(rs.p, cs.p)
   
    #create only one new mat
    finalmat <- matrix(0, nrow(web), ncol(web))

    # go through this loop until all dimensions are attained
    # Only the row and column of the drawn cell can change, so the marginals and the
    # zeroing of P are updated incrementally. The old loop recomputed rowSums(), colSums()
    # and a full outer() product of the whole matrix for every single interaction placed.
    nr <- nrow(web); nc <- ncol(web)
    row.used <- logical(nr); col.used <- logical(nc)
    n.int.finalmat <- 0
    while (n.int.finalmat < sum(dim(web))){
      # randomly select a cell, according to probability matrix P:
      sel <- sample.int(length(web), 1, prob=P, replace=TRUE) # replace=TRUE picks the much
      # cheaper sampling routine in R even for size 1 (~4x faster on a 80x80 web)
      finalmat[sel] <- 1
      r <- (sel - 1L) %% nr + 1L; cc <- (sel - 1L) %/% nr + 1L
      new.row <- !row.used[r]; new.col <- !col.used[cc]
      if (new.row) { row.used[r] <- TRUE; n.int.finalmat <- n.int.finalmat + 1 }
      if (new.col) { col.used[cc] <- TRUE; n.int.finalmat <- n.int.finalmat + 1 }
      # A cell can no longer add a new species once its row AND column are represented.
      # Only the newly used row/column can change that, so touch just those (the original
      # rebuilt a full outer() product over the whole matrix on every single draw).
      if (new.row) P[r, col.used] <- 0
      if (new.col) P[row.used, cc] <- 0
    }
    
  # Step 2. IV: fill up to full connectance:
  conn.remain <- sum(web>0) - sum(finalmat>0)
  if (conn.remain > 0) {
  	if (length(which(finalmat==0))==1){
    			add <- which(finalmat==0) # if there is only one possible cell, don't draw it randomly ...
    } else {
    			add <- sample(which(finalmat==0), conn.remain, prob=P1[finalmat==0])
    }
	finalmat[add] <- 1
  }
  
    # 3. step: now fill the filled cells with the remaining interactions:
    int.remain <- sum(web) - sum(finalmat)
    if (int.remain > 0){
	  add <- sample(which(finalmat>0), int.remain, prob=P1[which(finalmat>0)], replace=TRUE)
    finalmat[as.numeric(names(table(add)))] <- finalmat[as.numeric(names(table(add)))] + table(add)
    }
    # NOTE: This steps is very rough and yields large misfits of marginal totals. Ideally, one would do this in a loop and fill up only as much as there is still room in a column and row. That, however, becomes really difficult towards the end of the filling up!
	finalmat
  }

  # vectorised call of vaznull.fast:
  replicate(N, vaznull.fast(web), simplify=FALSE)

}
#vaznull(1, Safariland)
#system.time(vaznull(10, Safariland))
#system.time(swap.web(10, Safariland))
#system.time(nullmodel(Safariland, 10))