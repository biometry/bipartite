# bipartite 2.24 — correctness fixes and speedups

14 correctness defects fixed, 9 performance problems addressed, 2,211 lines of
unreachable C++ removed. Full write-up with evidence and measurements:
**bipartite-change-report.pdf**.

Headline: `networklevel()` with default arguments on a 40x60 web goes from
453 s to 13 s; the largest single win is 1,144x (`nest.smdm`).

## Contents

    bipartite-change-report.pdf   the change report (10 pages)
    bipartite/                    the fixed package source
    fixes.patch                   complete diff against the original
    make_libs.sh                  builds lib-before / lib-after for comparison
    verify/                       verification and benchmark scripts + results
    review/ (this dir)            the original review artefacts (t*.R, bench*.R,
                                  bipartite-review.html)

## Install

    R CMD INSTALL bipartite

## Reproducing the verification

    cd verify
    sh ../make_libs.sh            # builds lib-before and lib-after (needs git history)

    Rscript regression.R ../lib-before   # 0 of 14 assertions pass
    Rscript regression.R ../lib-after    # 14 of 14 pass

    Rscript nonregression.R ../lib-before before.rds
    Rscript nonregression.R ../lib-after  after.rds
    # 2,636 index values across 4 webs; 9 differ, all intended (togetherness, H2)

    Rscript smoke.R ../lib-before smoke_before.rds
    Rscript smoke.R ../lib-after  smoke_after.rds
    # 51 exported functions; 42 identical, 6 differ (the intended fixes)

    Rscript check_smdm.R     # 472 old-vs-new comparisons, 0 mismatches
    Rscript check_ctm.R      # 118 old-vs-new comparisons, 0 mismatches
    Rscript check_cscore.R   # 40 comparisons plus the degenerate case
    Rscript check_h2c.R      # 399 webs that trigger the H2max refinement

    ./run_bench.sh ../lib-before baseline.csv
    ./run_bench.sh ../lib-after  after.csv

`baseline_partial.csv` and `after.csv` in `verify/` are the runs the report
quotes. Each benchmark case runs in its own R process (`bench_case.R`).

The pre-fix sources of the four functions that were rewritten are kept beside
the checks as `smdm_old.R`, `ctm_old.R`, `cscore_old.R` and `h2_old.R`, so the
differential tests work without git.

## Environment used

R 4.5.0, vegan 2.7.6, sna 2.8, permute, corpcor; macOS arm64, single-threaded.
