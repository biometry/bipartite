.libPaths(c("lib", .libPaths())); suppressMessages(library(bipartite)); suppressMessages(library(vegan))
set.seed(2); n <- 60; m <- 80
w <- matrix(rpois(n*m, 0.7), n, m); w <- w[rowSums(w)>0, colSums(w)>0]
rownames(w) <- paste0("R",1:nrow(w)); colnames(w) <- paste0("C",1:ncol(w))
cat("web:", dim(w), " sum:", sum(w), " connectance:", round(sum(w>0)/prod(dim(w)),3), "\n\n")

cat("C.score(normalise=TRUE) :", system.time(a <- C.score(w))[["elapsed"]], "s\n")
cat("C.score(normalise=FALSE):", system.time(C.score(w, normalise=FALSE))[["elapsed"]], "s\n")
# memoised + lower-triangle-only version
C.score.fast <- function(web, normalise=TRUE, FUN=mean, ...){
  web <- (web>0)*1
  D <- designdist(t(web), method="(A-J)*(B-J)", terms="binary")
  if (!normalise) return(FUN(D, ...))
  simvec <- function(a,b,n){ res <- matrix(0, ncol=2, nrow=n)
    if (!(a==0|b==0|a==n|b==n)){
      if (a<=n/2) res[1:(2*a),1] <- rep(c(1,0), times=a) else {
        p <- rep(c(1,0), times=floor(n/2)); res[1:length(p),1] <- p
        res[rev(which(res[,1]==0))[1:(a-sum(res[,1]))],1] <- 1 }
      if (b<=n/2) res[1:(2*b),2] <- rep(c(0,1), times=b) else {
        p <- rep(c(0,1), times=floor(n/2)); res[1:length(p),2] <- p
        res[rev(which(res[,2]==0))[1:(b-sum(res[,2]))],2] <- 1 } }
    designdist(t(res), method="(A-J)*(B-J)", terms="binary") }
  k <- colSums(web>0); n <- NROW(web); nc <- NCOL(web)
  cache <- new.env(hash=TRUE)
  get1 <- function(a,b){ key <- paste(min(a,b), max(a,b)); v <- cache[[key]]
    if (is.null(v)) { v <- as.numeric(simvec(a,b,n)); assign(key, v, envir=cache) }; v }
  idx <- which(lower.tri(matrix(0,nc,nc)), arr.ind=TRUE)
  Cm <- mapply(function(i,j) get1(k[i],k[j]), idx[,1], idx[,2])
  FUN(as.vector(D)/Cm, ...) }
cat("C.score memoised        :", system.time(b <- C.score.fast(w))[["elapsed"]], "s   identical:", isTRUE(all.equal(a,b)), "\n\n")

cat("nest.smdm(weighted=FALSE):", system.time(nest.smdm(w>0))[["elapsed"]], "s\n")
cat("nestednodf (vegan, C)    :", system.time(nestednodf(w>0))[["elapsed"]], "s\n\n")
cat("H2fun                   :", system.time(H2fun(w))[["elapsed"]], "s\n")
cat("vaznull(1)              :", system.time(vaznull(1, w))[["elapsed"]], "s\n")
