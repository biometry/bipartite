.libPaths(c("lib", .libPaths())); suppressMessages(library(bipartite)); suppressMessages(library(vegan))
cat("--- C.score scaling in number of columns (memoisation payoff) ---\n")
for (nc in c(40, 80, 160)) {
  set.seed(3); w <- matrix(rpois(50*nc, .7), 50, nc); w <- w[rowSums(w)>0, colSums(w)>0]
  t <- system.time(C.score(w))[["elapsed"]]
  cat(sprintf("  %3d columns: %6.2f s  (%d simvec() calls, %d distinct degree pairs)\n",
      ncol(w), t, ncol(w)^2, nrow(unique(t(apply(expand.grid(colSums(w>0),colSums(w>0)),1,sort)))) )) }

cat("\n--- nest.smdm: triple R loop vs vectorised equivalent ---\n")
nodf.vec <- function(x){ # vectorised unweighted NODF, rows
  tab0 <- x[order(rowSums(x), decreasing=TRUE), order(colSums(x), decreasing=TRUE)]
  MT <- rowSums(tab0); b <- tab0==1
  S <- tcrossprod(b)            # pairwise co-occurrence counts
  N <- matrix(NA_real_, nrow(tab0), nrow(tab0))
  for (j in 2:nrow(tab0)) for (i in 1:(j-1))
    N[j,i] <- if (MT[j] >= MT[i]) 0 else S[j,i]*100/MT[j]
  mean(N, na.rm=TRUE) }
for (n in c(60, 120, 200)) {
  set.seed(4); w <- (matrix(rpois(n*n, .7), n, n) > 0)*1
  w <- w[rowSums(w)>0, colSums(w)>0]; rownames(w)<-paste0("R",1:nrow(w)); colnames(w)<-paste0("C",1:ncol(w))
  t1 <- system.time(a <- nest.smdm(w)$NODFrow)[["elapsed"]]
  t2 <- system.time(b <- nodf.vec(w))[["elapsed"]]
  cat(sprintf("  %3dx%3d: nest.smdm %6.2f s | crossprod version %6.3f s | same result: %s\n",
      nrow(w), ncol(w), t1, t2, isTRUE(all.equal(a,b)))) }

cat("\n--- H2fun scaling in total number of interactions ---\n")
for (mult in c(1, 4, 16)) {
  set.seed(5); w <- matrix(rpois(30*30, .8), 30, 30)*mult; w <- w[rowSums(w)>0, colSums(w)>0]
  cat(sprintf("  sum(web) = %6d : %6.2f s\n", sum(w), system.time(H2fun(w))[["elapsed"]])) }
