.libPaths(c("lib", .libPaths())); suppressMessages(library(bipartite))
cat("--- H2fun scaling in matrix size (the while-loop is O(cells) iterations x O(cells) work) ---\n")
for (n in c(40, 80, 120)) {
  set.seed(6); w <- matrix(rpois(n*n, 1), n, n); w <- w[rowSums(w)>0, colSums(w)>0]
  tot <- sum(w); ex <- outer(rowSums(w), colSums(w)/tot); iters <- tot - sum(floor(ex))
  cat(sprintf("  %3dx%3d (%d cells, sum=%d): %6.2f s  [while-loop iterations: %d]\n",
      nrow(w), ncol(w), prod(dim(w)), tot, system.time(H2fun(w))[["elapsed"]], iters)) }
cat("\n--- does the 'tries in 1:500' block ever trigger? ---\n")
data(Safariland); w <- as.matrix(Safariland)
ex <- outer(rowSums(w), colSums(w)/sum(w)); cat("Safariland: max(exexpec) =", max(ex), " vs 0.3679*tot =", 0.3679*sum(w), "->", max(ex) > 0.3679*sum(w), "\n")
w2 <- matrix(c(100,1,1,1), 2); ex2 <- outer(rowSums(w2), colSums(w2)/sum(w2))
cat("dominated 2x2: triggers =", max(ex2) > 0.3679*sum(w2), " time:", system.time(H2fun(w2))[["elapsed"]], "s\n")
