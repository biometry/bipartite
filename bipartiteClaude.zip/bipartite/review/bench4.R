.libPaths(c("lib", .libPaths())); suppressMessages(library(bipartite)); data(Safariland)
w <- as.matrix(Safariland)
cat("H2fun(Safariland):", round(system.time(for(i in 1:20) H2fun(w))[["elapsed"]]/20, 4), "s per call\n")
# how many of the 500 'tries' actually change anything?
tot <- sum(w); rs <- rowSums(w); cs <- colSums(w); exexpec <- outer(rs, cs/tot)
newweb <- floor(exexpec); webfull <- matrix("no", nrow(w), ncol(w))
while (sum(newweb) < tot) { webfull[which(rowSums(newweb)==rs),] <- "yo"; webfull[,which(colSums(newweb)==cs)] <- "yo"
  OK <- webfull=="no"; sp <- newweb==min(newweb[OK]); gd <- max((exexpec-newweb)[sp & OK])
  bo <- which(OK & sp & (exexpec-newweb)==gd); if (length(bo)>1) bo <- sample(bo,1); newweb[bo] <- newweb[bo]+1 }
prev <- newweb; changed <- 0; last <- 0
for (tries in 1:500){ newmx <- newweb; difexp <- exexpec-newmx; gd <- difexp==min(difexp)
  if (sum(gd)>1){ lv <- newmx==max(newmx[gd]); first <- gd & lv } else first <- gd
  newmx[first][1] <- newmx[first][1]-1
  throw <- which(rowSums(first)>0)[1]; thcol <- which(colSums(first)>0)[1]
  mr <- max(difexp[throw,]); mc <- max(difexp[,thcol])
  if (mr>=mc){ scnd <- which(difexp[throw,]==mr)[1]; newmx[throw,scnd] <- newmx[throw,scnd]+1
    thrd <- which(difexp[,scnd]==min(difexp[,scnd]))[1]; newmx[thrd,scnd] <- newmx[thrd,scnd]-1; newmx[thrd,thcol] <- newmx[thrd,thcol]+1
  } else { scnd <- which(difexp[,thcol]==mc)[1]; newmx[scnd,thcol] <- newmx[scnd,thcol]+1
    thrd <- which(difexp[scnd,]==min(difexp[scnd,]))[1]; newmx[scnd,thrd] <- newmx[scnd,thrd]-1; newmx[throw,thrd] <- newmx[throw,thrd]+1 }
  if (!identical(newmx, newweb)) { changed <- changed+1; last <- tries }
  newweb <- newmx }
cat("of 500 'tries' iterations,", changed, "changed the matrix; last change at iteration", last, "\n")
