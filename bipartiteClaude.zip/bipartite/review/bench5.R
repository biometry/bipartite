.libPaths(c("lib", .libPaths())); suppressMessages(library(bipartite)); data(Safariland)
w <- as.matrix(Safariland); tot <- sum(w); rs <- rowSums(w); cs <- colSums(w); exexpec <- outer(rs, cs/tot)
newweb <- floor(exexpec); webfull <- matrix("no", nrow(w), ncol(w))
while (sum(newweb) < tot) { webfull[which(rowSums(newweb)==rs),] <- "yo"; webfull[,which(colSums(newweb)==cs)] <- "yo"
  OK <- webfull=="no"; sp <- newweb==min(newweb[OK]); gd <- max((exexpec-newweb)[sp & OK])
  bo <- which(OK & sp & (exexpec-newweb)==gd); if (length(bo)>1) bo <- sample(bo,1); newweb[bo] <- newweb[bo]+1 }
H2 <- function(m) -sum(m/tot*log(m/tot), na.rm=TRUE)
start <- H2(newweb); trace <- numeric(500)
for (tries in 1:500){ newmx <- newweb; difexp <- exexpec-newmx; gd <- difexp==min(difexp)
  if (sum(gd)>1){ lv <- newmx==max(newmx[gd]); first <- gd & lv } else first <- gd
  newmx[first][1] <- newmx[first][1]-1
  throw <- which(rowSums(first)>0)[1]; thcol <- which(colSums(first)>0)[1]
  mr <- max(difexp[throw,]); mc <- max(difexp[,thcol])
  if (mr>=mc){ scnd <- which(difexp[throw,]==mr)[1]; newmx[throw,scnd] <- newmx[throw,scnd]+1
    thrd <- which(difexp[,scnd]==min(difexp[,scnd]))[1]; newmx[thrd,scnd] <- newmx[thrd,scnd]-1; newmx[thrd,thcol] <- newmx[thrd,thcol]+1
  } else { scnd <- which(difexp[,thcol]==mc)[1]; newmx[scnd,thcol] <- newmx[scnd,thcol]+1
    thrd <- which(difexp[scnd,]==min(difexp[scnd,]))[1]; newmx[scnd,thrd] <- newmx[scnd,thrd]-1; newmx[throw,thrd] <- newmx[throw,thrd]+1 }
  newweb <- newmx; trace[tries] <- H2(newweb) }
cat("H2max before the 500-try loop :", round(start,6), "\n")
cat("H2max kept (last iterate)     :", round(trace[500],6), " <- what the code uses\n")
cat("best H2max seen during search :", round(max(trace),6), " (at iteration", which.max(trace), ")\n")
cat("iterations WORSE than the best:", sum(trace < max(trace)), "of 500\n")
cat("marginal totals preserved?    :", all(rowSums(newweb)==rs) && all(colSums(newweb)==cs), "\n")
