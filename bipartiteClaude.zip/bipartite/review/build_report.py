#!/usr/bin/env python3
"""Builds the change report PDF from the measured verification data."""
import csv, os, subprocess
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer,
                                Table, TableStyle, KeepTogether, PageBreak)

OUT = "bipartite-change-report.pdf"
INK   = colors.HexColor("#16211E")
INK2  = colors.HexColor("#42524D")
INK3  = colors.HexColor("#6B7B75")
RULE  = colors.HexColor("#D9E1DC")
ACC   = colors.HexColor("#0E5B58")
BUG   = colors.HexColor("#9C3121")
PERF  = colors.HexColor("#8A5A0C")
SOFT  = colors.HexColor("#EEF2EF")
GOOD  = colors.HexColor("#12603A")

def S(name, **kw):
    base = dict(name=name, fontName="Helvetica", fontSize=9.2, leading=13.2,
                textColor=INK2, alignment=TA_LEFT, spaceAfter=5)
    base.update(kw); return ParagraphStyle(**base)

st = {
 "h1":   S("h1", fontName="Helvetica-Bold", fontSize=20, leading=23, textColor=INK, spaceAfter=3),
 "sub":  S("sub", fontSize=10.5, leading=15, textColor=INK3, spaceAfter=14),
 "h2":   S("h2", fontName="Helvetica-Bold", fontSize=13.5, leading=17, textColor=INK,
           spaceBefore=16, spaceAfter=7),
 "h3":   S("h3", fontName="Helvetica-Bold", fontSize=10.2, leading=13.6, textColor=INK,
           spaceBefore=9, spaceAfter=3),
 "body": S("body"),
 "small":S("small", fontSize=8.3, leading=11.6, textColor=INK3),
 "loc":  S("loc", fontName="Courier", fontSize=7.9, leading=10.6, textColor=INK3, spaceAfter=4),
 "code": S("code", fontName="Courier", fontSize=7.9, leading=11, textColor=INK,
           backColor=SOFT, borderPadding=(5,6,5,6), spaceBefore=3, spaceAfter=6),
 "ev":   S("ev", fontSize=8.6, leading=12.2, textColor=INK2, backColor=colors.HexColor("#E8F1EF"),
           borderPadding=(5,6,5,6), leftIndent=0, spaceBefore=3, spaceAfter=6),
 "cell": S("cell", fontSize=8.2, leading=11),
 "cellb":S("cellb", fontSize=8.2, leading=11, fontName="Helvetica-Bold", textColor=INK),
}

story = []
def P(t, s="body"): story.append(Paragraph(t, st[s]))
def SP(h=4): story.append(Spacer(1, h))

def tag(txt, col):
    return ('<font face="Helvetica-Bold" color="#%s">%s</font>' % (col.hexval()[2:], txt))

def finding(fid, title, colour, loc, paras):
    blk = [Paragraph("%s &nbsp;&nbsp;%s" % (tag(fid, colour), title), st["h3"])]
    if loc: blk.append(Paragraph(loc, st["loc"]))
    for kind, txt in paras:
        blk.append(Paragraph(txt, st[kind]))
    story.append(KeepTogether(blk))

def table(rows, widths, align_right=(), header=True, fs=8.2):
    data = []
    for r_i, r in enumerate(rows):
        row = []
        for c_i, c in enumerate(r):
            sty = "cellb" if (header and r_i == 0) else "cell"
            row.append(Paragraph(str(c), st[sty]))
        data.append(row)
    t = Table(data, colWidths=widths, repeatRows=1 if header else 0)
    cmds = [("VALIGN",(0,0),(-1,-1),"TOP"),
            ("LINEBELOW",(0,0),(-1,0),0.7,INK) if header else ("LINEBELOW",(0,0),(-1,0),0.25,RULE),
            ("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white, colors.HexColor("#F7F9F8")]),
            ("TOPPADDING",(0,0),(-1,-1),3.5),("BOTTOMPADDING",(0,0),(-1,-1),3.5),
            ("LEFTPADDING",(0,0),(-1,-1),5),("RIGHTPADDING",(0,0),(-1,-1),5),
            ("LINEBELOW",(0,1),(-1,-2),0.25,RULE)]
    for c in align_right: cmds.append(("ALIGN",(c,0),(c,-1),"RIGHT"))
    t.setStyle(TableStyle(cmds))
    story.append(t); SP(7)

# ---------------------------------------------------------------- data
def read_csv(p):
    d = {}
    with open(p) as f:
        for row in csv.reader(f):
            if len(row) == 2 and row[0] != "case":
                try: d[row[0]] = float(row[1])
                except ValueError: pass
    return d

before = read_csv("verify/baseline_partial.csv")
after  = read_csv("verify/after.csv")

LABEL = {
 "cscore":     ("C.score(normalise=TRUE)", "P1"),
 "smdm_bin":   ("nest.smdm(), binary", "P2"),
 "smdm_wt":    ("nest.smdm(weighted=TRUE)", "P2"),
 "h2fun":      ("H2fun()", "P3"),
 "grouplevel": ("grouplevel()", "P5"),
 "secondext":  ("second.extinct()", "P6"),
 "vaznull":    ("vaznull(), 20 nulls", "P7"),
 "netlevel":   ("networklevel(), all indices", "P9"),
 "netlevel_saf":("networklevel(), all indices", "P9"),
 "splevel_saf":("specieslevel(), all indices", "-"),
}
def web_of(k):
    p = k.split(":")
    if p[0].endswith("_saf"): return "Safariland 9x27"
    return "%sx%s" % (p[1], p[2])

def fmt(s):
    if s is None: return "n/a"
    if s >= 100: return "%.1f" % s
    if s >= 10:  return "%.2f" % s
    if s >= 1:   return "%.3f" % s
    return ("%.4f" % s).rstrip("0").rstrip(".")


# ---------------------------------------------------------------- page 1
P("bipartite 2.24 &ndash; correctness fixes and speedups", "h1")
P("14 correctness defects fixed, 9 performance problems addressed, 2,211 lines of unreachable "
  "C++ removed. Every fix is backed by an assertion that fails on the original code and passes "
  "on the new one; every speedup is backed by a before/after measurement on the same machine.", "sub")

rows = [["", "Result"],
 ["Correctness defects fixed", "14 &nbsp;(regression suite: 0/14 pass before, 14/14 after)"],
 ["Performance problems fixed", "9 &nbsp;(largest single win: 1,144&times;)"],
 ["End-to-end effect", "<font color='#0E5B58'><b>networklevel() on a 40&times;60 web: 453 s &rarr; 13 s</b></font>"],
 ["Peak memory", "clustering_tm on 40&times;60: 6.3 GB &rarr; 1.4 GB"],
 ["Unintended changes", "<font color='#12603A'><b>none</b></font> &nbsp;&ndash; 2,636 index values compared across 4 webs, "
  "9 differ and all 9 are intended fixes"],
 ["Code removed", "2,546 lines (2,211 of them dead C++)"],
]
table(rows, [46*mm, 116*mm])

P("How this was verified", "h2")
P("Four independent checks, all scripted and re-runnable from <font face='Courier'>review/verify/</font>:", "body")
rows = [["Check", "What it does", "Result"],
 ["<font face='Courier'>regression.R</font>",
  "One assertion per bug, stating the behaviour that <i>should</i> hold.",
  "0/14 pass on the original, 14/14 after"],
 ["<font face='Courier'>nonregression.R</font>",
  "Dumps every networklevel and specieslevel index for Safariland, vazquenc, memmott1999 and a "
  "random 15&times;20 web, then diffs the two builds value by value.",
  "2,636 values compared, 9 differ &ndash; all of them togetherness (B4) and H2 (B9)"],
 ["<font face='Courier'>smoke.R</font>",
  "Calls 51 exported functions on Safariland under a fixed seed and compares the returned objects.",
  "42 identical, 6 differ (the intended fixes), 0 new errors"],
 ["differential tests",
  "For the three rewritten internals (nest.smdm, clustering_tm, C.score) the old and new "
  "implementations are run side by side on hundreds of random webs.",
  "nest.smdm 472 comparisons, clustering_tm 118, C.score 40 &ndash; <b>zero</b> mismatches"],
]
table(rows, [30*mm, 88*mm, 44*mm])
P("Environment: R 4.5.0, vegan 2.7.6, sna 2.8, permute, corpcor, macOS (arm64), single-threaded. "
  "Timings are elapsed seconds; each benchmark case runs in its own R process.", "small")

story.append(PageBreak())

# ---------------------------------------------------------------- speedups
P("Performance", "h2")
P("Each row is one benchmark case, measured on the original code and on the new code in separate "
  "R processes. Cases marked &ldquo;at timer resolution&rdquo; were already fast enough that the "
  "measurement is noise; they are listed for completeness because the code did change.", "body")

order = ["cscore:50:40","cscore:50:80","cscore:50:160",
         "smdm_bin:60:60","smdm_bin:120:120","smdm_bin:200:200",
         "smdm_wt:60:60","smdm_wt:120:120",
         "h2fun:40:40","h2fun:80:80","h2fun:120:120",
         "vaznull:40:40","vaznull:80:80",
         "grouplevel:80:80","grouplevel:160:160","secondext:30:30","secondext:50:50",
         "netlevel_saf:0:0","netlevel:40:60","splevel_saf:0:0"]
rows = [["ID","Function","Web","Before (s)","After (s)","Speed-up"]]
for k in order:
    b, a = before.get(k), after.get(k)
    lab, pid = LABEL[k.split(":")[0]]
    if b is None or a is None: sp = "n/a"
    elif b < 0.005: sp = "<font color='#6B7B75'>at timer resolution</font>"
    else:
        r = b / a if a > 0 else float("inf")
        col = "#0E5B58" if r >= 2 else "#42524D"
        sp = "<font color='%s'><b>%s&times;</b></font>" % (col, ("%.0f" % r) if r >= 10 else ("%.1f" % r))
    rows.append([pid, lab, web_of(k), fmt(b), fmt(a), sp])
table(rows, [10*mm, 50*mm, 26*mm, 22*mm, 22*mm, 32*mm], align_right=(3,4))

P("clustering_tm measured on its own (time and peak resident memory)", "h3")
rows = [["Web","Before","After","Speed-up","Peak RSS before","Peak RSS after"],
 ["20&times;20","1.25 s","0.03 s","<font color='#0E5B58'><b>42&times;</b></font>","397 MB","312 MB"],
 ["30&times;30","13.45 s","0.49 s","<font color='#0E5B58'><b>27&times;</b></font>","1,102 MB","498 MB"],
 ["40&times;60","170.71 s","2.83 s","<font color='#0E5B58'><b>60&times;</b></font>","6,307 MB","1,439 MB"]]
table(rows, [22*mm, 24*mm, 22*mm, 26*mm, 34*mm, 34*mm], align_right=(1,2))
P("This function was not in the original review. It surfaced while benchmarking: it is the reason "
  "<font face='Courier'>networklevel()</font> with default arguments took 453 s and several "
  "gigabytes on a 40&times;60 web, and it accounts for nearly all of the 35&times; end-to-end gain.", "small")

story.append(PageBreak())
P("How each speedup was obtained", "h2")

speed = [
 ("P1","C.score()","bipartite/R/C.score.R:50-78",
  "The normalisation loop called <font face='Courier'>simvec()</font> &ndash; which builds an "
  "n&times;2 matrix and runs <font face='Courier'>designdist()</font> on it &ndash; once for every "
  "<i>ordered</i> pair of species including the diagonal, then used only the lower triangle. "
  "<font face='Courier'>simvec()</font> depends solely on the two occupancies and the number of "
  "sites, and is symmetric in them.",
  "Compute the lower triangle only and memoise on <font face='Courier'>(min(a,b), max(a,b))</font>. "
  "On a 50&times;160 web that is 210 distinct evaluations instead of 25,600 calls."),
 ("P2","nest.smdm()","bipartite/R/nest.smdm.R (six loop nests)",
  "Six blocks of the shape <font face='Courier'>for (j) for (i) { S&lt;-0; for (k) if (cond) S&lt;-S+1 }</font>, "
  "i.e. O(n&sup2;m) interpreted operations to build one count matrix.",
  "Two helpers: <font face='Courier'>cooccurrence.count()</font> is <font face='Courier'>tcrossprod(m == 1)</font> "
  "for the binary case; <font face='Courier'>dominance.count()</font> accumulates one "
  "<font face='Courier'>outer()</font> per column for the weighted case. "
  "<font face='Courier'>fill.N()</font> then fills the lower triangle in one vectorised step."),
 ("P3","H2fun()","bipartite/R/H2fun.R:35-60, 80-115",
  "The fill loop runs about one pass per two cells and each pass re-scanned the whole matrix with "
  "<font face='Courier'>rowSums()</font>/<font face='Courier'>colSums()</font> and rebuilt "
  "<font face='Courier'>difexp</font>, even though exactly one cell changes per pass. A "
  "character matrix of &ldquo;no&rdquo;/&ldquo;yo&rdquo; tracked which cells were still available. "
  "A further 500 refinement passes ran unconditionally.",
  "Running marginals updated in place, a logical matrix instead of strings, and the refinement loop "
  "stops after 50 passes without improvement (see B9). Note the first pass still compares against "
  "the empty web, as in all earlier versions &ndash; that quirk was left alone so results stay comparable."),
 ("P5","grouplevel()","bipartite/R/grouplevel.R:71-72",
  "<font face='Courier'>apply(web, 1, sum)</font> and <font face='Courier'>apply(web, 2, sum)</font>.",
  "<font face='Courier'>rowSums()</font> / <font face='Courier'>colSums()</font> &ndash; 17&times; faster "
  "in isolation on a 500&times;500 matrix, though it is not the bottleneck in any realistic call."),
 ("P6","second.extinct()","bipartite/R/second.extinct.R:25-34, 51",
  "The result matrix was grown with <font face='Courier'>rbind()</font> inside a "
  "<font face='Courier'>repeat</font> loop, reallocating and copying on every pass. This is what "
  "turned the B2 hang into a multi-gigabyte one.",
  "Preallocate <font face='Courier'>sum(dim(web)) + 1</font> rows, fill by index, trim at the end, "
  "and raise a clear error if the sequence ever exceeds that bound."),
 ("P7","vaznull()","bipartite/R/vaznull.r:22-43",
  "Every placed interaction triggered <font face='Courier'>rowSums()</font>, "
  "<font face='Courier'>colSums()</font> and a fresh full <font face='Courier'>outer()</font> product "
  "over the whole probability matrix, although only the drawn cell's row and column can change.",
  "Track used rows/columns in two logical vectors and zero only the newly used row and column. "
  "<font face='Courier'>replace=TRUE</font> is kept on the <font face='Courier'>sample.int()</font> call: "
  "dropping it selects a different sampling routine in R and is 4&times; slower even for size 1 "
  "(an early version of this patch was measurably slower for exactly that reason)."),
 ("P8","networklevel(), grouplevel()","bipartite/R/networklevel.R:13, grouplevel.R:41",
  "<font face='Courier'>empty(web)</font> was called, then called again on the already-emptied web.",
  "One call when <font face='Courier'>empty.web=TRUE</font> (the default)."),
 ("P9","clustering_tm()","bipartite/R/clustering_tm.R (rewritten)",
  "All 4-paths were materialised at once by a chain of <font face='Courier'>merge()</font> calls &ndash; "
  "millions of rows, growing roughly cubically with web size. Three "
  "<font face='Courier'>apply(..., 1, ...)</font> calls then computed the geometric mean, max and min "
  "row by row, and a fourth per-row <font face='Courier'>apply()</font> tested each path for a 6-cycle "
  "using two list lookups and an <font face='Courier'>as.character()</font> conversion.",
  "Three changes. (1) The weight columns are computed with vectorised arithmetic and "
  "<font face='Courier'>pmax</font>/<font face='Courier'>pmin</font>. (2) The 6-cycle test becomes one "
  "matrix lookup: since i1~p1 and i3~p2 hold by construction, the number of shared partners excluding "
  "p1 and p2 is <font face='Courier'>S[i1,i3] - B[i3,p1] - B[i1,p2]</font>, where "
  "<font face='Courier'>B</font> is the incidence matrix and <font face='Courier'>S = tcrossprod(B)</font>. "
  "(3) The final expansion is done in chunks of 200,000 rows with the column sums accumulated, which "
  "is what bounds the memory."),
]
for pid, fn, loc, was, now in speed:
    blk = [Paragraph("%s &nbsp;&nbsp;%s" % (tag(pid, PERF), fn), st["h3"]),
           Paragraph(loc, st["loc"]),
           Paragraph("<b>Was:</b> " + was, st["body"]),
           Paragraph("<b>Now:</b> " + now, st["body"])]
    story.append(KeepTogether(blk))

story.append(PageBreak())
P("Correctness fixes", "h2")
P("Ordered as in the original review. Each entry gives the location, the defect, the fix, and the "
  "evidence that distinguishes the two.", "body")

bugs = [
 ("B1","shuffle.web() lost and invented interactions","bipartite/R/shuffle.web.R:56 and :68",
  "<font face='Courier'>out[option[sample(...), ]] &lt;- remains</font> indexes an "
  "<font face='Courier'>arr.ind</font> matrix of zero cells. When exactly one interaction was left "
  "the result dropped to a length-2 vector, so <font face='Courier'>c(row, col)</font> was "
  "reinterpreted as two <i>linear</i> indices and the value was written into two arbitrary cells.",
  "Added <font face='Courier'>, drop=FALSE</font> in both the legacy and the Rabie branch.",
  "3&times;3 web, sum 17, 4 links. Before: seeds 1&ndash;5 produced nulls with sums 18, 21, 19, 13, 12 "
  "and one with 5 links. After: all 25 seeds give sum 17 and 4 links, which are the invariants this "
  "null model is defined by. Affects <font face='Courier'>nullmodel(method=\"shuffle.web\")</font> too."),
 ("B2","second.extinct() never terminated for participant=\"both\", method=\"degree\"","bipartite/R/extinction.R:56-80",
  "The degree branch handled <font face='Courier'>partis.match</font> 1 and 2 only, so "
  "<font face='Courier'>participant=\"both\"</font> fell through and returned the web untouched. "
  "<font face='Courier'>second.extinct()</font>'s <font face='Courier'>repeat</font> loop could then "
  "never reach a break condition.",
  "Implemented the \"both\" case: remove the most connected species from whichever level holds it, "
  "ties broken at random, mirroring the existing abundance branch. "
  "<font face='Courier'>method=\"external\"</font> with \"both\" now raises an explicit error, since a "
  "per-level sequence has no meaning there.",
  "Before: <font face='Courier'>identical(extinction(Safariland, \"both\", \"degree\"), Safariland)</font> "
  "was TRUE, and <font face='Courier'>second.extinct()</font> ran past two minutes and 6 GB on a 9&times;27 "
  "web before being killed. After: it returns in well under a second."),
 ("B3","dfun() added two phantom interactions","bipartite/R/dfun.R:19",
  "<font face='Courier'>for (j in 1:restuse)</font>. When the expected values came out integral, "
  "<font face='Courier'>restuse</font> was 0 and <font face='Courier'>1:0</font> is "
  "<font face='Courier'>c(1, 0)</font> &ndash; so the loop ran twice and the minimally-specialised "
  "reference vector ended up with two interactions the species does not have.",
  "<font face='Courier'>seq_len(restuse)</font>.",
  "For <font face='Courier'>matrix(c(2,2,0, 0,0,8, 2,2,0), 3, byrow=TRUE)</font> every row has "
  "<font face='Courier'>restuse == 0</font>. dmin before: 0.0283, 0.0101, 0.0283; after: 0, 0, 0. "
  "d&prime; before: 0.4896, 1, 0.4896; after: 0.5, 1, 0.5. Reaches users through "
  "<font face='Courier'>specieslevel(index=\"d\")</font> and <font face='Courier'>networklevel(index=\"SA\")</font>."),
 ("B4","togetherness() normalised by a scalar, not per species pair","bipartite/R/togetherness.r:17",
  "Inside <font face='Courier'>designdist()</font>, A and B are vectors with one element per pair. "
  "<font face='Courier'>min(max(A*(P-A)), max(B*(P-B)))</font> collapses them to a single global "
  "number, so every pair was divided by the same constant &ndash; and the outer "
  "<font face='Courier'>min</font> was a no-op because both <font face='Courier'>max</font> terms "
  "reduce to the same value. The comment two lines above describes the intended per-pair minimum.",
  "<font face='Courier'>pmin(A*(P-A), B*(P-B))</font>.",
  "On a random 8&times;5 binary web the shipped maxD was the constant 16; the per-pair maxima are "
  "15, 7, 12, 16, 7, 12, 15, 7, 7, 12. togetherness before 0.219, after 0.354. "
  "This is one of only two indices whose values change (see the non-regression table)."),
 ("B5","ND(normalised=FALSE) returned half the degree","bipartite/R/ND.r:9",
  "<font face='Courier'>Nlow &lt;- Nhigh &lt;- 2 # effectively unnormalised</font>. Dividing by two is "
  "not unnormalised.",
  "Divisor set to 1.",
  "Safariland lower level: <font face='Courier'>rowSums(web &gt; 0)</font> is 6, 17, 1, 2, ...; "
  "before the function returned 3, 8.5, 0.5, 1, ...; after it matches the degree exactly."),
 ("B6","networklevel(index=\"binary\") silently dropped two of its seven indices","bipartite/R/networklevel.R:43 and :362",
  "The shortcut named <font face='Courier'>\"mean number of partners\"</font> and "
  "<font face='Courier'>\"C-score\"</font>; the real names are "
  "<font face='Courier'>\"mean number of shared partners\"</font> and "
  "<font face='Courier'>\"C score\"</font>. The validity check only ever saw the user's string "
  "(<font face='Courier'>\"binary\"</font>), and grouplevel discarded unknown names without a word.",
  "Both names corrected, in the modern and in the legacy copy. Separately, "
  "<font face='Courier'>one.grouplevel()</font> now warns about any index name it does not recognise, "
  "so a typo of this kind cannot go unnoticed again.",
  "Before, <font face='Courier'>networklevel(Safariland, index=\"binary\")</font> returned neither the "
  "C-score nor the shared-partner count and issued no message. After, both appear."),
 ("B7","nested() accepted a typo whenever one other name was valid","bipartite/R/nested.r:4",
  "<font face='Courier'>if (!any(method %in% valid))</font> passes as long as a single element matches.",
  "<font face='Courier'>all()</font>, and the error now names the offending entries. The duplicated "
  "<font face='Courier'>\"binmatnest\"</font> in the <font face='Courier'>\"ALL\"</font> vector was "
  "removed at the same time.",
  "<font face='Courier'>nested(Safariland, c(\"NODF\", \"bogus-index\"))</font> returned just NODF "
  "silently; it now stops."),
 ("B8","nullmodel() ran both shuffle branches for webs with values in (1,2)","bipartite/R/nullmodel.r:52-61",
  "<font face='Courier'>if (any(web &gt; 1))</font> and <font face='Courier'>if (all(web &lt; 2))</font> "
  "were independent statements, so a web whose maximum fell between 1 and 2 satisfied both and the "
  "quantitative result was overwritten by the binary quasiswap.",
  "A single <font face='Courier'>if/else</font> keyed on whether the web is actually binary.",
  "A web with values {0, 0.5, 1.5} came back as {0, 1}. It now keeps its quantitative values."),
]
for bid, title, loc, was, fix, ev in bugs:
    blk = [Paragraph("%s &nbsp;&nbsp;%s" % (tag(bid, BUG), title), st["h3"]),
           Paragraph(loc, st["loc"]),
           Paragraph("<b>Defect:</b> " + was, st["body"]),
           Paragraph("<b>Fix:</b> " + fix, st["body"]),
           Paragraph("<b>Evidence:</b> " + ev, st["ev"])]
    story.append(KeepTogether(blk))

bugs2 = [
 ("B9","H2fun() kept the last refinement iterate instead of the best one","bipartite/R/H2fun.R:80-115",
  "The refinement loop shuffles interactions between cells 500 times looking for a higher "
  "<font face='Courier'>H2max</font>, but never recorded the best matrix it saw &ndash; only the 500th "
  "iterate survived. The search wanders rather than converging (it changed the matrix on all 500 passes "
  "on every web tested), so the final iterate is usually not the best one. "
  "<font face='Courier'>H2max</font> is a maximum, so a worse late iterate is never the right answer.",
  "Track the best matrix and its H2, and stop after 50 passes without an improvement.",
  "Safariland: best value during the search 2.361531 at pass 13, value previously kept 2.360304. "
  "Across 399 webs that trigger the refinement, H2max improved on 317 and got worse on <b>none</b> "
  "(median gain 0.016, maximum 0.072). Safariland H2&prime; moves from 0.85373 to 0.85543. "
  "The function is also 2.5&times; faster on Safariland as a side effect."),
 ("B10","nestedness() silently ignored six of its seven arguments","bipartite/R/nestedness.R:7-16",
  "Since the binmatnest C++ back end was retired in April 2022 the body has been "
  "<font face='Courier'>vegan::nestedtemp(m)</font>. <font face='Courier'>null.models</font>, "
  "<font face='Courier'>n.nulls</font>, <font face='Courier'>popsize</font>, "
  "<font face='Courier'>n.ind</font>, <font face='Courier'>n.gen</font> and "
  "<font face='Courier'>binmatnestout</font> were accepted and discarded without a signal.",
  "The function now warns, naming exactly which of the supplied arguments have no effect and "
  "pointing at <font face='Courier'>vegan::oecosimu()</font> for null models. The arguments are kept "
  "so existing calls still run.",
  "<font face='Courier'>nestedness(Safariland, n.nulls=1000)</font> used to return quietly; it now warns."),
 ("B11","C.score() returned NaN whenever a species occupied every site","bipartite/R/C.score.R:70-78",
  "<font face='Courier'>simvec()</font> returns 0 when either occupancy is 0 or equal to the number of "
  "sites, so those pairs computed 0/0. The default <font face='Courier'>FUN=mean</font> carries no "
  "<font face='Courier'>na.rm</font>, so one generalist poisoned the whole index.",
  "Pairs for which no checkerboard can exist are excluded from the summary, with a warning saying how "
  "many were dropped and why.",
  "<font face='Courier'>C.score(matrix(c(1,1,1, 1,0,1, 1,1,0), 3, byrow=TRUE))</font> was NaN; it is "
  "now 1 with an explanatory warning. On 40 random webs with no degenerate species the value is "
  "bit-identical to before."),
 ("B12","grouplevel() failed with \"object 'for.higher' not found\"","bipartite/R/grouplevel.R:2-6",
  "<font face='Courier'>level</font> was only validated inside <font face='Courier'>one.grouplevel()</font>, "
  "which is reached after <font face='Courier'>for.higher</font> is read, so a typo produced an internal "
  "error message instead of the intended one.",
  "Validate <font face='Courier'>level</font> at the top and derive the two flags from it.",
  "<font face='Courier'>grouplevel(Safariland, level=\"hihger\")</font> now says "
  "&ldquo;Please choose a valid level&rdquo;."),
 ("B13","Two unguarded loops and a floating-point loop exit","bipartite/R/swap.web.R:60-73, H2fun.R:129",
  "<font face='Courier'>findmat.empty()</font> searched for a qualifying 2&times;2 submatrix with no "
  "iteration cap, while its sibling <font face='Courier'>findmat.full()</font> takes a "
  "<font face='Courier'>c.crit</font> guard for exactly that reason. Separately, "
  "<font face='Courier'>H2fun()</font> terminated a loop on "
  "<font face='Courier'>round(sum(rsrest), 10) != 0</font> &ndash; floating-point equality with a "
  "hard-coded tolerance; the code comment records Bob O'Hara's suggestion to use "
  "<font face='Courier'>all.equal</font>, never applied.",
  "<font face='Courier'>findmat.empty()</font> takes the same <font face='Courier'>c.crit</font> cap and "
  "raises an informative error instead of spinning; the H2fun exit uses "
  "<font face='Courier'>all.equal</font>. Also fixed nearby: <font face='Courier'>findmat.full()</font> "
  "was being called without <font face='Courier'>c.crit</font> in the retry path, and a "
  "<font face='Courier'>cat()</font> diagnostic fired regardless of the "
  "<font face='Courier'>verbose</font> argument.",
  "Marked <i>by inspection</i> in the original review and still so: I could not construct a web that "
  "reaches the unguarded loop, because the fully connected case exits earlier through "
  "<font face='Courier'>upswap()</font>'s <font face='Courier'>m == n</font> shortcut. The cap closes "
  "the asymmetry regardless."),
]
for bid, title, loc, was, fix, ev in bugs2:
    blk = [Paragraph("%s &nbsp;&nbsp;%s" % (tag(bid, BUG), title), st["h3"]),
           Paragraph(loc, st["loc"]),
           Paragraph("<b>Defect:</b> " + was, st["body"]),
           Paragraph("<b>Fix:</b> " + fix, st["body"]),
           Paragraph("<b>Evidence:</b> " + ev, st["ev"])]
    story.append(KeepTogether(blk))

story.append(PageBreak())
P("What changed in the numbers", "h2")
P("The point of the non-regression check is that a fix should change exactly what it claims to change "
  "and nothing else. Across four webs, 2,636 index values from "
  "<font face='Courier'>networklevel()</font> and <font face='Courier'>specieslevel()</font> were "
  "compared between the two builds. Nine differ:", "body")
rows = [["Index","Web","Before","After","Why"]]
diffs = [("H2","Safariland","0.85373072","0.85542740","B9"),
 ("togetherness.HL","Safariland","0.16068376","0.37295940","B4"),
 ("togetherness.HL","memmott1999","0.09741260","0.34454490","B4"),
 ("togetherness.HL","random15x20","0.19417293","0.24337460","B4"),
 ("togetherness.HL","vazquenc","0.22977053","0.45036230","B4"),
 ("togetherness.LL","Safariland","0.03529412","0.12046320","B4"),
 ("togetherness.LL","memmott1999","0.10312854","0.35511760","B4"),
 ("togetherness.LL","random15x20","0.19733333","0.24116350","B4"),
 ("togetherness.LL","vazquenc","0.03459821","0.14025970","B4")]
for a_,b_,c_,d_,e_ in diffs: rows.append([a_,b_,c_,d_,e_])
table(rows, [32*mm, 30*mm, 28*mm, 28*mm, 44*mm], align_right=(2,3))
P("Every other index &ndash; connectance, nestedness, NODF, weighted NODF, modularity, linkage density, "
  "ISA, SA, Fisher alpha, evenness, C score, discrepancy, niche overlap, generality, vulnerability, "
  "functional complementarity, all the species-level indices &ndash; is unchanged to full precision. "
  "The C-score is unchanged here because none of these four webs contains a species that occupies "
  "every site; B11 only bites when one does.", "body")
P("One near-miss worth recording: replacing "
  "<font face='Courier'>ifelse(inherits(nest, \"try-error\"), NA, nest)</font> with a plain "
  "<font face='Courier'>if/else</font> preserved the <font face='Courier'>\"temperature\"</font> name "
  "that vegan attaches to its statistic, which <font face='Courier'>ifelse()</font> had been silently "
  "stripping. The nestedness value was identical but its label changed from "
  "<font face='Courier'>nestedness</font> to <font face='Courier'>nestedness.temperature</font>. "
  "The non-regression diff caught it and the result is now wrapped in "
  "<font face='Courier'>unname()</font>.", "body")

P("Dead code and cleanups", "h2")
rows = [["Where","What"],
 ["<font face='Courier'>src/bmn5.cc</font>",
  "Deleted. 2,211 lines of C++ compiled on every install with its only R caller commented out since "
  "April 2022 and its registration in <font face='Courier'>init.c</font> commented out too. Nothing "
  "includes it. Removing it cuts compile time roughly in half. "
  "<font face='Courier'>MersenneTwister.h</font> stays &ndash; <font face='Courier'>dendro.h</font> "
  "pulls it in for <font face='Courier'>identifyModules</font>."],
 ["<font face='Courier'>grouplevel.R:16-20</font>",
  "Removed a block that computed <font face='Courier'>out</font> and was immediately overwritten by a "
  "character-for-character identical block five lines later."],
 ["<font face='Courier'>empty.R:12-20</font>",
  "Removed the one-row/one-column special case: it computed <font face='Courier'>nr</font> and "
  "<font face='Courier'>nc</font> and discarded them, because its <font face='Courier'>return()</font> "
  "statements had been commented out. The generic path with "
  "<font face='Courier'>drop=FALSE</font> handles those shapes."],
 ["<font face='Courier'>robustness.r</font>, <font face='Courier'>slope.bipartite.R</font>, <font face='Courier'>ND.r</font>",
  "Removed <font face='Courier'>N &lt;- colSums(object)</font> (twice) and "
  "<font face='Courier'>k &lt;- sum(web)</font> &ndash; all three were never read."],
 ["<font face='Courier'>second.extinct.R:82</font>",
  "Removed <font face='Courier'>if (is.vector(method)) sequence = method</font>: "
  "<font face='Courier'>sequence</font> was never read and the condition is always true for a "
  "length-1 character. Also removed a pointless <font face='Courier'>rm(nr)</font> inside a loop."],
 ["<font face='Courier'>swap.web.R</font>",
  "Removed an unreachable <font face='Courier'>stop()</font> after a "
  "<font face='Courier'>return()</font>, and a second <font face='Courier'>if</font> that re-tested "
  "the complement of the condition just checked (and recomputed the sum to do it)."],
 ["<font face='Courier'>specieslevel.R:24-25</font>",
  "Removed the duplicated <font face='Courier'>ALL</font>/<font face='Courier'>ALLBUTD</font> "
  "expansion; the <font face='Courier'>switch()</font> below already does it."],
 ["<font face='Courier'>networklevel.R:307</font>",
  "<font face='Courier'>if (exists(\"outg\"))</font> searches enclosing environments and would pick up "
  "a user's global variable of that name; now <font face='Courier'>if (length(gindex) &gt; 0)</font>."],
 ["five files",
  "<font face='Courier'>T</font>/<font face='Courier'>F</font> replaced with "
  "<font face='Courier'>TRUE</font>/<font face='Courier'>FALSE</font> "
  "(<font face='Courier'>decimalr2dtable.R</font>, <font face='Courier'>nest.smdm.R</font>, "
  "<font face='Courier'>restrictednull.R</font>, <font face='Courier'>plotmatrix.R</font>); "
  "<font face='Courier'>ifelse()</font> on scalars replaced with "
  "<font face='Courier'>if/else</font>; a bare <font face='Courier'>try()</font> that printed to the "
  "console given <font face='Courier'>silent=TRUE</font>."],
]
table(rows, [40*mm, 122*mm])

P("Deliberately left alone", "h2")
rows = [["Item","Reason"],
 ["The <font face='Courier'>.networklevel()</font> legacy copy (391 lines)",
  "Reachable through the documented <font face='Courier'>legacy=TRUE</font> argument, so removing it "
  "would be a breaking API change and is the maintainers' call. The B6 index-name typo was fixed in "
  "<i>both</i> copies. This duplication is still how B6 arose and is worth consolidating."],
 ["The stale first pass in <font face='Courier'>H2fun()</font>'s fill loop",
  "<font face='Courier'>difexp</font> is initialised against the empty web rather than against "
  "<font face='Courier'>newweb</font>, so the first pass compares against the wrong baseline. It looks "
  "unintended, but changing it would move H2max on every web, which is beyond a fix I can justify from "
  "the review. Flagged here instead, with a comment in the source."],
 ["The <font face='Courier'>dead2[,2] &lt;- 1</font> hack in <font face='Courier'>second.extinct()</font>",
  "A blanket overwrite guarding against a &ldquo;completely mystifying bug&rdquo; per its own comment. "
  "Diagnosing the underlying cause needs the maintainers' knowledge of the intended semantics."],
 ["Pre-existing NaN from <font face='Courier'>H2fun()</font> on some tiny webs",
  "When H2max and H2min coincide the ratio is 0/0. This is documented at the foot of the file as a "
  "long-standing issue and occurs at the same rate before and after (1 web in 199 tested)."],
 ["Plotting functions (about 1,500 lines)",
  "Not touched. Defects there are visual and need a human looking at output."],
 ["<font face='Courier'>src/identifyModules.cc</font> and headers (5,400 lines)",
  "Not touched; checked for linkage only."],
]
table(rows, [46*mm, 116*mm])

P("Files changed", "h2")

rows = [['File','Added','Removed']]
rows.append(["<font face='Courier'>R/C.score.R</font>", '35', '32'])
rows.append(["<font face='Courier'>R/H2fun.R</font>", '30', '11'])
rows.append(["<font face='Courier'>R/ND.r</font>", '2', '2'])
rows.append(["<font face='Courier'>R/clustering_tm.R</font>", '114', '81'])
rows.append(["<font face='Courier'>R/decimalr2dtable.R</font>", '2', '2'])
rows.append(["<font face='Courier'>R/dfun.R</font>", '1', '1'])
rows.append(["<font face='Courier'>R/empty.R</font>", '3', '9'])
rows.append(["<font face='Courier'>R/extinction.R</font>", '14', '11'])
rows.append(["<font face='Courier'>R/grouplevel.R</font>", '17', '13'])
rows.append(["<font face='Courier'>R/nest.smdm.R</font>", '40', '90'])
rows.append(["<font face='Courier'>R/nested.r</font>", '3', '2'])
rows.append(["<font face='Courier'>R/nestedness.R</font>", '9', '1'])
rows.append(["<font face='Courier'>R/networklevel.R</font>", '11', '11'])
rows.append(["<font face='Courier'>R/nullmodel.r</font>", '23', '19'])
rows.append(["<font face='Courier'>R/plotmatrix.R</font>", '1', '1'])
rows.append(["<font face='Courier'>R/restrictednull.R</font>", '1', '1'])
rows.append(["<font face='Courier'>R/robustness.r</font>", '1', '1'])
rows.append(["<font face='Courier'>R/second.extinct.R</font>", '14', '4'])
rows.append(["<font face='Courier'>R/shuffle.web.R</font>", '23', '23'])
rows.append(["<font face='Courier'>R/slope.bipartite.R</font>", '1', '1'])
rows.append(["<font face='Courier'>R/specieslevel.R</font>", '2', '2'])
rows.append(["<font face='Courier'>R/swap.web.R</font>", '16', '11'])
rows.append(["<font face='Courier'>R/togetherness.r</font>", '3', '1'])
rows.append(["<font face='Courier'>R/vaznull.r</font>", '16', '5'])
rows.append(["<font face='Courier'>src/bmn5.cc</font>", '0', '2211'])
table(rows, [96*mm, 26*mm, 26*mm], align_right=(1,2))

P("Reproducing all of this", "h2")
P("Everything below runs from <font face='Courier'>review/verify/</font>. "
  "<font face='Courier'>lib-before</font> holds the package built from the original sources and "
  "<font face='Courier'>lib-after</font> the fixed one, so both can be exercised side by side in one "
  "session.", "body")
P("Rscript regression.R ../lib-before &nbsp;# 0/14 pass<br/>"
  "Rscript regression.R ../lib-after &nbsp;&nbsp;# 14/14 pass<br/>"
  "Rscript nonregression.R ../lib-before before.rds<br/>"
  "Rscript nonregression.R ../lib-after &nbsp;after.rds<br/>"
  "Rscript smoke.R ../lib-before smoke_before.rds<br/>"
  "Rscript check_smdm.R &nbsp;&nbsp;&nbsp;# 472 old-vs-new comparisons, 0 mismatches<br/>"
  "Rscript check_ctm.R &nbsp;&nbsp;&nbsp;&nbsp;# 118 old-vs-new comparisons, 0 mismatches<br/>"
  "Rscript check_cscore.R &nbsp;# 40 comparisons plus the degenerate case<br/>"
  "Rscript check_h2c.R &nbsp;&nbsp;&nbsp;&nbsp;# 399 webs that trigger the H2max refinement<br/>"
  "./run_bench.sh ../lib-before baseline.csv<br/>"
  "./run_bench.sh ../lib-after &nbsp;after.csv", "code")
P("The original sources of the three rewritten functions are kept beside the checks as "
  "<font face='Courier'>smdm_old.R</font>, <font face='Courier'>ctm_old.R</font>, "
  "<font face='Courier'>cscore_old.R</font> and <font face='Courier'>h2_old.R</font>, so the "
  "differential tests do not depend on git.", "small")

# ------------------------------------------------------------------ render
def deco(canv, doc):
    canv.saveState()
    canv.setFont("Helvetica", 7.5); canv.setFillColor(INK3)
    canv.drawString(20*mm, 12*mm, "bipartite 2.24 — correctness fixes and speedups")
    canv.drawRightString(A4[0]-20*mm, 12*mm, "page %d" % doc.page)
    canv.setStrokeColor(RULE); canv.setLineWidth(0.5)
    canv.line(20*mm, 15.5*mm, A4[0]-20*mm, 15.5*mm)
    canv.restoreState()

doc = BaseDocTemplate(OUT, pagesize=A4, leftMargin=20*mm, rightMargin=20*mm,
                      topMargin=18*mm, bottomMargin=20*mm,
                      title="bipartite 2.24 - correctness fixes and speedups",
                      author="code review", subject="Change report")
frame = Frame(20*mm, 20*mm, A4[0]-40*mm, A4[1]-38*mm, id="f", showBoundary=0)
doc.addPageTemplates([PageTemplate(id="main", frames=[frame], onPage=deco)])
doc.build(story)
print("wrote", OUT)
