#!/bin/sh
# Rebuilds the two library trees the verification scripts compare.
#   lib-before : bipartite as it was before the fixes (git HEAD~1)
#   lib-after  : bipartite with the fixes (the working tree)
# Run from the directory that contains this script.
set -e
REPO=$(cd .. && pwd)
mkdir -p lib-before lib-after
tmp=$(mktemp -d)
git -C "$REPO" archive HEAD~1 bipartite | tar -x -C "$tmp"
R CMD INSTALL --no-docs "$tmp/bipartite" -l lib-before
rm -rf "$tmp"
R CMD INSTALL --no-docs "$REPO/bipartite" -l lib-after
echo "built lib-before and lib-after"
