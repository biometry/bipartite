source("../bipartite/R/empty.R")
source("../bipartite/R/dfun.R")
# web where q*sum(x) is exactly integer -> restuse == 0
w <- matrix(c(2,2, 3,1), nrow=2, byrow=TRUE)  # colSums 5,3 ; sum 8
cat("colSums:", colSums(w), " sum:", sum(w), "\n")
q <- colSums(w)/sum(w)
for (i in 1:nrow(w)) {
  x <- w[i,]
  expec <- floor(q*sum(x)); cat("row",i,"x=",x," expec=",expec," restuse=",sum(x)-sum(expec),"\n")
}
print(dfun(w))
# demonstrate 1:0 problem directly
restuse <- 0
cat("1:restuse gives:", 1:restuse, "\n")
