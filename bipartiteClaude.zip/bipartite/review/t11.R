.libPaths(c("lib", .libPaths())); suppressMessages(library(bipartite))
src <- readLines("../bipartite/R/nest.smdm.R")
# insert the missing reorder line right before line 62 (NODFrow = mean(Nrow...)) in the UNWEIGHTED branch
i <- grep("^    NODFrow = mean\\(Nrow, na.rm = TRUE\\)$", src)[1]
cat("patching before source line", i, ":", src[i], "\n")
src2 <- append(src, "    Nrow=Nrow[rownames(x), rownames(x)]", after=i-1)
env <- new.env(parent=environment(bipartite::nest.smdm)); eval(parse(text=paste(src2, collapse="\n")), envir=env)
nest.smdm.fixed <- env$nest.smdm

set.seed(11)
w <- matrix(rbinom(9*7, 1, .45), 9, 7)
rownames(w) <- paste0("R", 1:9); colnames(w) <- paste0("C", 1:7)
w <- w[rowSums(w)>0, colSums(w)>0]
cons <- c(rep(c(1,2), length.out=nrow(w)), rep(c(1,2), length.out=ncol(w)))
a <- nest.smdm(w, constraints=cons, weighted=FALSE)
b <- nest.smdm.fixed(w, constraints=cons, weighted=FALSE)
cmp <- data.frame(index=names(a), current=unlist(a), with_missing_line=unlist(b))
print(cmp, row.names=FALSE)
