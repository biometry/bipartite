.libPaths(c("lib", .libPaths())); suppressMessages(library(bipartite))
src <- readLines("../bipartite/R/nest.smdm.R")
i <- grep("^    NODFrow = mean\\(Nrow, na.rm = TRUE\\)$", src)[1]
src2 <- append(src, "    Nrow=Nrow[rownames(x), rownames(x)]", after=i-1)
env <- new.env(parent=environment(bipartite::nest.smdm)); eval(parse(text=paste(src2, collapse="\n")), envir=env)
fixed <- env$nest.smdm
set.seed(1); ndiff <- 0
for (s in 1:200){
  set.seed(s)
  w <- matrix(rbinom(8*6,1,.5), 8, 6); rownames(w)<-paste0("R",1:8); colnames(w)<-paste0("C",1:6)
  if (any(rowSums(w)==0)||any(colSums(w)==0)) next
  cons <- c(sample(rep(c("A","B"), length.out=8)), sample(rep(c("A","B"), length.out=6)))
  a <- try(nest.smdm(w, constraints=cons, weighted=FALSE), silent=TRUE)
  b <- try(fixed(w, constraints=cons, weighted=FALSE), silent=TRUE)
  if (inherits(a,"try-error")||inherits(b,"try-error")) next
  if (!isTRUE(all.equal(unlist(a), unlist(b)))){ ndiff <- ndiff+1
    if (ndiff<=2){ cat("\n--- seed", s, "row order permuted by sorting:", !identical(order(rowSums(w),decreasing=TRUE), 1:8), "---\n")
      print(rbind(current=unlist(a), fixed=unlist(b))) } } }
cat("\nseeds where SM/DM values differ:", ndiff, "out of 200\n")
