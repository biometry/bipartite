.libPaths(c("lib", .libPaths())); suppressMessages(library(bipartite)); data(Safariland)
w <- as.matrix(Safariland)
cat("=== ND(normalised=FALSE) should be the raw degree ===\n")
cat("rowSums(web>0)   :", head(rowSums(w>0)), "\n")
cat("ND(normalised=F) :", head(ND(w, normalised=FALSE)$lower), "  <- halved\n")
cat("=== mgen inner allocation loop vs tabulate ===\n")
set.seed(1); m <- matrix(runif(60*80), 60, 80); m <- m/sum(m); n <- 20000
f_loop <- function(){ mint <- matrix(0,60,80); iv <- sample(1:length(mint), n, TRUE, prob=m); for (i in iv) mint[i] <- mint[i]+1; mint }
f_tab  <- function(){ mint <- matrix(0,60,80); iv <- sample(1:length(mint), n, TRUE, prob=m); mint + tabulate(iv, nbins=length(mint)) }
cat("  loop     :", system.time(for(k in 1:20) f_loop())[["elapsed"]], "s (20 reps)\n")
cat("  tabulate :", system.time(for(k in 1:20) f_tab())[["elapsed"]], "s (20 reps)\n")
set.seed(2); a <- f_loop(); set.seed(2); b <- f_tab(); cat("  identical:", identical(a,b), "\n")
