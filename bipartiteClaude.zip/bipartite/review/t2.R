source("../bipartite/R/empty.R")
source("../bipartite/R/dfun.R")
w <- matrix(c(1,1, 2,2), nrow=2, byrow=TRUE)  # colSums 3,3, q=.5,.5
cat("colSums:", colSums(w), "\n")
r <- dfun(w)
print(r)
# instrument dminfind manually for row 1
q <- c(.5,.5); cs <- colSums(w); abuns <- NULL
x <- w[1,]
expec <- floor(q*sum(x)); restuse <- sum(x)-sum(expec)
cat("expec:",expec," restuse:",restuse," -> loop indices:",1:restuse,"\n")
x.new <- expec
for (j in 1:restuse){ i.vec <- which(x.new < cs); xsum <- sum(x.new); p.1 <- x.new/(xsum+1)
  dstep.1 <- ifelse(x.new!=0, p.1*log(p.1/q), 0); d.check <- numeric(0)
  for (i in i.vec){ pi.1 <- (x.new[i]+1)/(xsum+1); d.check[i] <- pi.1*log(pi.1/q[i]) + sum(dstep.1[-i]) }
  ib <- which.min(d.check)[1]; x.new[ib] <- x.new[ib]+1
  cat("  iteration j=",j," -> x.new:",x.new,"  (sum",sum(x.new),")\n") }
cat("x had sum", sum(x), "but constructed x.new has sum", sum(x.new), "\n")
