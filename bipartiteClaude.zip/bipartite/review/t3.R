source("../bipartite/R/empty.R")
source("../bipartite/R/dfun.R")
dfun.buggy <- dfun
# patched version: seq_len instead of 1:restuse
txt <- readLines("../bipartite/R/dfun.R")
txt <- sub("for \\(j in 1:restuse\\)", "for (j in seq_len(restuse))", txt)
eval(parse(text=paste(txt, collapse="\n")))
dfun.fixed <- dfun
w <- matrix(c(4,0,0, 0,4,0, 0,0,8), nrow=3, byrow=TRUE)
cat("colSums:", colSums(w), " rowSums:", rowSums(w), "\n")
b <- dfun.buggy(w); f <- dfun.fixed(w)
cat("buggy dmin :", b$dmin, "\n"); cat("fixed dmin :", f$dmin, "\n")
cat("buggy dprime:", b$dprime, "\n"); cat("fixed dprime:", f$dprime, "\n")
