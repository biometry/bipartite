source("../bipartite/R/empty.R")
source("../bipartite/R/dfun.R"); dfun.buggy <- dfun
txt <- sub("for \\(j in 1:restuse\\)", "for (j in seq_len(restuse))", readLines("../bipartite/R/dfun.R"))
eval(parse(text=paste(txt, collapse="\n"))); dfun.fixed <- dfun
w <- matrix(c(2,2,0, 0,0,8, 2,2,0), nrow=3, byrow=TRUE)
cat("colSums:", colSums(w), "rowSums:", rowSums(w), "\n")
b <- dfun.buggy(w); f <- dfun.fixed(w)
cat("buggy  d':", round(b$dprime,6), " dmin:", round(b$dmin,6), "\n")
cat("fixed  d':", round(f$dprime,6), " dmin:", round(f$dmin,6), "\n")
