source("../bipartite/R/empty.R"); source("../bipartite/R/shuffle.web.R")
set.seed(1)
# a web where exactly one interaction remains after diagonal+off-diagonal allocation
w <- matrix(c(5,0,0, 0,3,0, 0,0,2, 1,0,0), nrow=4, byrow=TRUE)  # 4x3, 4 non-zero cells
cat("dim:", dim(w), " nonzero:", sum(w>0), "\n")
for (s in 1:6){ set.seed(s)
  r <- try(shuffle.web(w, 1)[[1]], silent=TRUE)
  if (inherits(r,"try-error")) { cat("seed",s,"ERROR:", attr(r,"condition")$message, "\n") } else {
  cat("seed",s," sum in:",sum(w)," sum out:",sum(r)," nonzero out:",sum(r>0),"\n") } }
cat("\n--- square web, legacy=FALSE ---\n")
sq <- matrix(c(3,0,1, 0,2,0, 1,0,4), 3, byrow=TRUE)
r <- try(shuffle.web(sq, 1, legacy=FALSE), silent=TRUE)
cat(if (inherits(r,"try-error")) paste("ERROR:", attr(r,"condition")$message) else "ok", "\n")
