source("../bipartite/R/empty.R"); source("../bipartite/R/shuffle.web.R")
sq <- matrix(c(5,0,0, 0,3,0, 7,0,2), 3, byrow=TRUE)  # 3x3, 4 nonzero -> exactly 1 'remains'
cat("in : sum =", sum(sq), " nonzero =", sum(sq>0), "\n")
for (s in 1:5){ set.seed(s); r <- shuffle.web(sq,1)[[1]]
  cat("seed",s,": sum =",sum(r)," nonzero =",sum(r>0),"\n"); if (s==1) print(r) }
cat("\n--- square + legacy=FALSE ---\n")
for (s in 1:3){ set.seed(s); r <- try(shuffle.web(sq,1,legacy=FALSE), silent=TRUE)
 cat("seed",s,":", if (inherits(r,"try-error")) attr(r,"condition")$message else paste("sum",sum(r[[1]]),"nonzero",sum(r[[1]]>0)), "\n") }
