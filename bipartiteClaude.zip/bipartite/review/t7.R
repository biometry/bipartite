suppressMessages(library(vegan))
source("../bipartite/R/togetherness.r")
set.seed(4)
w <- matrix(rbinom(40,1,.5), 8, 5)
web <- w>0
# what the package computes:
maxD <- designdist(t(web), method="min(max(A*(P-A)), max(B*(P-B)))", terms="minimum")
cat("maxD as computed (should be per-pair):\n"); print(as.vector(maxD))
# what the comment says it wants:
maxD.intended <- designdist(t(web), method="pmin(A*(P-A), B*(P-B))", terms="minimum")
cat("per-pair maximum (intended):\n"); print(as.vector(maxD.intended))
cat("\ntogetherness (package)  :", togetherness(w), "\n")
D <- designdist(t(web), method="J*(P-A-B+J)", terms="minimum")
cat("togetherness (per-pair) :", mean(D/maxD.intended), "\n")
