"""Line-oriented patch helper that preserves each file's original line endings."""
import io, re, sys

def read(p):
    raw = io.open(p, 'rb').read().decode('utf-8')
    crlf = raw.count('\r\n') > raw.count('\n') - raw.count('\r\n')
    return raw.replace('\r\n', '\n').split('\n'), ('\r\n' if crlf else '\n')

def write(p, lines, eol):
    io.open(p, 'wb').write(eol.join(lines).encode('utf-8'))

def find(lines, needle, start=0):
    """Index of the first line whose stripped text contains needle."""
    for i in range(start, len(lines)):
        if needle in lines[i]:
            return i
    raise AssertionError("not found: %r" % needle[:70])

def replace_block(path, first, last, new, occurrence=1):
    """Replace lines [first..last] (matched by substring) with the list `new`."""
    lines, eol = read(path)
    i = 0
    for _ in range(occurrence):
        i = find(lines, first, i) if _ == 0 else find(lines, first, i + 1)
    j = find(lines, last, i)
    lines[i:j+1] = new
    write(path, lines, eol)
    print("  %s: replaced lines %d-%d (%d -> %d lines)" % (path, i+1, j+1, j-i+1, len(new)))

def replace_line(path, needle, new, occurrence=1):
    lines, eol = read(path)
    i = -1
    for _ in range(occurrence):
        i = find(lines, needle, i + 1)
    lines[i:i+1] = new if isinstance(new, list) else [new]
    write(path, lines, eol)
    print("  %s: line %d" % (path, i+1))

def sub_in_line(path, needle, old, new, occurrence=1):
    lines, eol = read(path)
    i = -1
    for _ in range(occurrence):
        i = find(lines, needle, i + 1)
    assert old in lines[i], (path, lines[i])
    lines[i] = lines[i].replace(old, new)
    write(path, lines, eol)
    print("  %s: line %d" % (path, i+1))
