# One benchmark case per process:  Rscript bench_case.R <lib> <case-id>
args <- commandArgs(TRUE); .libPaths(c(args[1], .libPaths()))
suppressMessages(library(bipartite)); suppressMessages(library(vegan)); id <- args[2]
mkweb <- function(n, m, seed, lambda=0.7){ set.seed(seed); w <- matrix(rpois(n*m, lambda), n, m)
  w <- w[rowSums(w)>0, colSums(w)>0, drop=FALSE]
  rownames(w) <- paste0("R",1:nrow(w)); colnames(w) <- paste0("C",1:ncol(w)); w }
tm <- function(expr, reps=1) system.time(for(i in seq_len(reps)) force(expr))[["elapsed"]]/reps
p <- strsplit(id, ":")[[1]]; what <- p[1]; n <- as.integer(p[2]); m <- as.integer(p[3])
set.seed(1)
sec <- switch(what,
  "cscore"      = { w <- mkweb(n, m, 3);            tm(C.score(w)) },
  "smdm_bin"    = { w <- (mkweb(n, m, 4) > 0)*1; rownames(w)<-paste0("R",1:nrow(w)); colnames(w)<-paste0("C",1:ncol(w)); tm(nest.smdm(w)) },
  "smdm_wt"     = { w <- mkweb(n, m, 14);           tm(nest.smdm(w, weighted=TRUE)) },
  "h2fun"       = { w <- mkweb(n, m, 6, 1);         tm(H2fun(w)) },
  "grouplevel"  = { w <- mkweb(n, m, 7);            tm(suppressWarnings(grouplevel(w, index="number of species")), reps=5) },
  "secondext"   = { w <- mkweb(n, m, 8);            tm(second.extinct(w, participant="higher", method="abundance")) },
  "vaznull"     = { w <- mkweb(n, m, 9);            tm(vaznull(20, w)) },
  "netlevel"    = { w <- mkweb(n, m, 11);           tm(suppressWarnings(networklevel(w))) },
  "netlevel_saf"= { data(Safariland);               tm(suppressWarnings(networklevel(as.matrix(Safariland))), reps=3) },
  "splevel_saf" = { data(Safariland);               tm(suppressWarnings(specieslevel(as.matrix(Safariland))), reps=3) },
  stop("unknown case"))
cat(sprintf("%s,%.4f\n", id, sec))
