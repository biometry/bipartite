# Benchmark suite: run as  Rscript bench_suite.R <libpath> <outfile.csv>
args <- commandArgs(TRUE); LIB <- args[1]; OUT <- args[2]
.libPaths(c(LIB, .libPaths())); suppressMessages(library(bipartite)); suppressMessages(library(vegan))
tm <- function(expr, reps=1){ t <- system.time(for(i in seq_len(reps)) force(expr))[["elapsed"]]; t/reps }
res <- list(); add <- function(case, web, sec) res[[length(res)+1]] <<- data.frame(case=case, web=web, sec=sec)

mkweb <- function(n, m, seed, lambda=0.7){ set.seed(seed); w <- matrix(rpois(n*m, lambda), n, m)
  w <- w[rowSums(w)>0, colSums(w)>0, drop=FALSE]; rownames(w) <- paste0("R",1:nrow(w)); colnames(w) <- paste0("C",1:ncol(w)); w }

# P1 C.score
for (nc in c(40,80,160)){ w <- mkweb(50, nc, 3); add("C.score (normalise=TRUE)", sprintf("50x%d", ncol(w)), tm(C.score(w))) }
# P2 nest.smdm
for (n in c(60,120,200)){ w <- (mkweb(n,n,4) > 0)*1
  rownames(w) <- paste0("R",1:nrow(w)); colnames(w) <- paste0("C",1:ncol(w))
  add("nest.smdm (unweighted)", sprintf("%dx%d", nrow(w), ncol(w)), tm(nest.smdm(w))) }
for (n in c(60,120)){ w <- mkweb(n,n,14)
  add("nest.smdm (weighted)", sprintf("%dx%d", nrow(w), ncol(w)), tm(nest.smdm(w, weighted=TRUE))) }
# P3/P4 H2fun
for (n in c(40,80,120)){ w <- mkweb(n,n,6,1); add("H2fun", sprintf("%dx%d", nrow(w), ncol(w)), tm(H2fun(w))) }
# P5 grouplevel
for (n in c(80,160)){ w <- mkweb(n,n,7); add("grouplevel (number of species)", sprintf("%dx%d", nrow(w), ncol(w)),
   tm(grouplevel(w, index="number of species"), reps=5)) }
# P6 second.extinct
for (n in c(40,80)){ w <- mkweb(n,n,8); add("second.extinct (higher, abundance)", sprintf("%dx%d", nrow(w), ncol(w)),
   tm(second.extinct(w, participant="higher", method="abundance"))) }
# P7 vaznull
for (n in c(40,80)){ w <- mkweb(n,n,9); add("vaznull (20 reps)", sprintf("%dx%d", nrow(w), ncol(w)), tm(vaznull(20, w))) }
# P8 + end-to-end
data(Safariland); saf <- as.matrix(Safariland)
add("networklevel ALLBUTDD", "Safariland 9x27", tm(suppressWarnings(networklevel(saf)), reps=3))
w <- mkweb(40,60,11); add("networklevel ALLBUTDD", "40x60", tm(suppressWarnings(networklevel(w))))
add("specieslevel ALLBUTD", "Safariland 9x27", tm(suppressWarnings(specieslevel(saf)), reps=3))

out <- do.call(rbind, res); write.csv(out, OUT, row.names=FALSE)
print(out, row.names=FALSE)
