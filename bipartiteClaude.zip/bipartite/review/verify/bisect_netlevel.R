.libPaths(c("../lib-before", .libPaths())); suppressMessages(library(bipartite))
set.seed(11); w <- matrix(rpois(40*60, 0.7), 40, 60); w <- w[rowSums(w)>0, colSums(w)>0]
rownames(w) <- paste0("R",1:nrow(w)); colnames(w) <- paste0("C",1:ncol(w))
cat("web:", dim(w), " sum:", sum(w), "\n")
idx <- commandArgs(TRUE)[1]
t <- system.time(r <- suppressWarnings(networklevel(w, index=idx)))[["elapsed"]]
cat(sprintf("%-32s %8.3f s   peak-mem %s MB\n", idx, t, round(sum(gc()[,6]))))
