suppressMessages(library(vegan))
source("../../bipartite/R/C.score.R")   # fixed
old <- local({ e <- new.env(); sys.source("cscore_old.R", e); e$C.score })
set.seed(1)
cat("--- identical results on webs with no degenerate species ---\n")
ok <- TRUE
for (s in 1:40){ set.seed(s); w <- matrix(rbinom(12*9, 1, .5), 12, 9)
  if (any(colSums(w) %in% c(0, nrow(w)))) next
  a <- old(w); b <- C.score(w)
  if (!isTRUE(all.equal(a, b))) { ok <- FALSE; cat("  MISMATCH seed", s, ":", a, "vs", b, "\n") } }
cat("  all equal:", ok, "\n")
cat("\n--- B11: a species on every site ---\n")
w <- matrix(c(1,1,1, 1,0,1, 1,1,0), 3, byrow=TRUE)
cat("  old:", old(w), "\n")
cat("  new:", withCallingHandlers(C.score(w), warning=function(w){cat("  warning:", conditionMessage(w), "\n"); invokeRestart("muffleWarning")}), "\n")
