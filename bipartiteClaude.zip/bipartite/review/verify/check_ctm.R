.libPaths(c("../lib-before", .libPaths())); suppressMessages(library(bipartite))
oe <- new.env(); sys.source("ctm_old.R", oe); old <- oe$clustering_tm
ne <- new.env(); sys.source("../../bipartite/R/clustering_tm.R", ne); new <- ne$clustering_tm
environment(old) <- environment(new) <- asNamespace("bipartite")
bad <- 0; n <- 0
for (s in 1:60){
  set.seed(s); d1 <- sample(4:14,1); d2 <- sample(4:14,1)
  w <- matrix(rpois(d1*d2, sample(c(.5,1,2),1)), d1, d2)
  w <- w[rowSums(w)>0, colSums(w)>0, drop=FALSE]
  if (nrow(w)<3 || ncol(w)<3) next
  el <- web2edges(w, return=TRUE)
  a <- suppressWarnings(old(el)); b <- suppressWarnings(new(el)); n <- n+1
  if (!isTRUE(all.equal(a, b))) { bad <- bad+1; cat("  WEIGHTED MISMATCH seed",s,"\n"); print(rbind(old=a,new=b)) }
  # binary two-mode
  elb <- el[, 1:2]
  ab <- suppressWarnings(old(elb)); bb <- suppressWarnings(new(elb))
  if (!isTRUE(all.equal(ab, bb))) { bad <- bad+1; cat("  BINARY MISMATCH seed",s,": ",ab," vs ",bb,"\n") }
}
cat("webs compared:", n, "(weighted + binary) | mismatches:", bad, "\n")
