oldenv <- new.env(); sys.source("h2_old.R", oldenv); old <- oldenv$H2fun
newenv <- new.env(); sys.source("../../bipartite/R/H2fun.R", newenv); new <- newenv$H2fun
cat("--- H2max must never get worse; H2' must stay in [0,1] ---\n")
worse <- 0; better <- 0; n <- 0
for (s in 1:120){
  set.seed(s); d1 <- sample(3:12,1); d2 <- sample(3:12,1)
  w <- matrix(rpois(d1*d2, sample(c(.5,1,3),1)), d1, d2)
  w <- w[rowSums(w)>0, colSums(w)>0, drop=FALSE]
  if (nrow(w)<2 || ncol(w)<2) next
  set.seed(1000+s); a <- old(w); set.seed(1000+s); b <- new(w)
  n <- n+1
  if (b["H2max"] < a["H2max"] - 1e-9) { worse <- worse+1; cat("  WORSE seed",s,":",a["H2max"],"->",b["H2max"],"\n") }
  if (b["H2max"] > a["H2max"] + 1e-9) better <- better+1
  stopifnot(is.finite(b["H2"]), b["H2"] >= -1e-9, b["H2"] <= 1+1e-9)
}
cat("  webs tested:", n, "| H2max worse:", worse, "| H2max improved:", better, "\n")
cat("\n--- Safariland ---\n")
suppressMessages({library(vegan)}); data(Safariland, package="bipartite")
w <- as.matrix(Safariland)
set.seed(4); print(round(old(w),6)); set.seed(4); print(round(new(w),6))
