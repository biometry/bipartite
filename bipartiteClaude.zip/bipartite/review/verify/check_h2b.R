oldenv <- new.env(); sys.source("h2_old.R", oldenv); old <- oldenv$H2fun
newenv <- new.env(); sys.source("../../bipartite/R/H2fun.R", newenv); new <- newenv$H2fun
worse <- 0; better <- 0; n <- 0; nanold <- 0; nannew <- 0; newnan_oldok <- 0
for (s in 1:200){
  set.seed(s); d1 <- sample(3:12,1); d2 <- sample(3:12,1)
  w <- matrix(rpois(d1*d2, sample(c(.5,1,3),1)), d1, d2)
  w <- w[rowSums(w)>0, colSums(w)>0, drop=FALSE]
  if (nrow(w)<2 || ncol(w)<2) next
  set.seed(1000+s); a <- old(w); set.seed(1000+s); b <- new(w); n <- n+1
  if (b["H2max"] < a["H2max"] - 1e-9){ worse <- worse+1
    cat("  WORSE seed",s,":",a["H2max"],"->",b["H2max"],"\n") }
  if (b["H2max"] > a["H2max"] + 1e-9) better <- better+1
  if (!is.finite(a["H2"])) nanold <- nanold + 1
  if (!is.finite(b["H2"])) { nannew <- nannew + 1
     if (is.finite(a["H2"])) { newnan_oldok <- newnan_oldok + 1; cat("  REGRESSION seed", s, "\n"); print(rbind(old=a, new=b)) } }
}
cat("webs:",n," H2max worse:",worse," improved:",better,
    "\nnon-finite H2 -- old:",nanold," new:",nannew," (new-only:",newnan_oldok,")\n")
