oldenv <- new.env(); sys.source("h2_old.R", oldenv); old <- oldenv$H2fun
newenv <- new.env(); sys.source("../../bipartite/R/H2fun.R", newenv); new <- newenv$H2fun
trig <- function(w){ tot<-sum(w); max(outer(rowSums(w), colSums(w)/tot)) > 0.3679*tot }
cat("--- webs where the 500-pass refinement actually triggers ---\n")
n<-0; worse<-0; better<-0; d<-c()
for (s in 1:400){
  set.seed(s); d1<-sample(3:10,1); d2<-sample(3:10,1)
  w <- matrix(rpois(d1*d2, .4), d1, d2)
  w[1,1] <- w[1,1] + sample(50:400,1)                   # one dominant cell
  w <- w[rowSums(w)>0, colSums(w)>0, drop=FALSE]
  if (nrow(w)<2||ncol(w)<2||!trig(w)) next
  set.seed(7); a<-old(w); set.seed(7); b<-new(w); n<-n+1
  if (b["H2max"] < a["H2max"]-1e-12){ worse<-worse+1; cat("  WORSE seed",s,"\n") }
  if (b["H2max"] > a["H2max"]+1e-12){ better<-better+1; d<-c(d, b["H2max"]-a["H2max"]) }
}
cat("  triggering webs:",n," H2max worse:",worse," improved:",better,"\n")
if(length(d)) cat("  median H2max gain:",signif(median(d),3)," max:",signif(max(d),3),"\n")
cat("\n--- Safariland ---\n")
data(Safariland, package="bipartite"); w <- as.matrix(Safariland)
set.seed(4); a <- old(w); set.seed(4); b <- new(w)
print(rbind(old=round(a,6), new=round(b,6)))
cat("timing (20 calls): old", system.time(for(i in 1:20) old(w))[["elapsed"]],
    "s | new", system.time(for(i in 1:20) new(w))[["elapsed"]], "s\n")
