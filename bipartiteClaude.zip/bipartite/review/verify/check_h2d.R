.libPaths(c("../lib-before", .libPaths()))
oldenv <- new.env(); sys.source("h2_old.R", oldenv); old <- oldenv$H2fun
newenv <- new.env(); sys.source("../../bipartite/R/H2fun.R", newenv); new <- newenv$H2fun
data(Safariland, package="bipartite"); w <- as.matrix(Safariland)
set.seed(4); a <- old(w); set.seed(4); b <- new(w)
print(rbind(old=round(a,6), new=round(b,6)))
cat("timing, 20 calls: old", system.time(for(i in 1:20) old(w))[["elapsed"]],
    "s | new", system.time(for(i in 1:20) new(w))[["elapsed"]], "s\n")
set.seed(6); big <- matrix(rpois(120*120,1),120,120); big <- big[rowSums(big)>0, colSums(big)>0]
cat("120x120: old", system.time(old(big))[["elapsed"]], "s | new", system.time(new(big))[["elapsed"]], "s\n")
cat("120x120 H2':  old", old(big)["H2"], " new", new(big)["H2"], "\n")
