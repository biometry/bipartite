suppressMessages(library(vegan))
oldenv <- new.env(); sys.source("smdm_old.R", oldenv); old <- oldenv$nest.smdm
newenv <- new.env(); sys.source("../../bipartite/R/nest.smdm.R", newenv); new <- newenv$nest.smdm
mismatch <- 0; tested <- 0
cmp <- function(a, b, tag){
  tested <<- tested + 1
  ua <- unlist(a); ub <- unlist(b)
  if (!isTRUE(all.equal(ua, ub))) { mismatch <<- mismatch + 1
    cat("  MISMATCH", tag, "\n"); print(rbind(old=ua, new=ub)) } }
set.seed(99)
for (s in 1:60){
  set.seed(s)
  n <- sample(4:14, 1); m <- sample(4:14, 1)
  w <- matrix(rpois(n*m, sample(c(0.4, 0.8, 1.5), 1)), n, m)
  w <- w[rowSums(w)>0, colSums(w)>0, drop=FALSE]
  if (nrow(w) < 3 || ncol(w) < 3) next
  rownames(w) <- paste0("R", seq_len(nrow(w))); colnames(w) <- paste0("C", seq_len(ncol(w)))
  cons <- c(sample(rep(c("A","B","C"), length.out=nrow(w))), sample(rep(c("A","B","C"), length.out=ncol(w))))
  for (cs in list(NULL, cons)) {
    tag <- paste0("seed=", s, " dim=", nrow(w), "x", ncol(w), " constraints=", !is.null(cs))
    cmp(suppressWarnings(old(w, constraints=cs, weighted=FALSE)),
        suppressWarnings(new(w, constraints=cs, weighted=FALSE)), paste(tag, "| unweighted NODF"))
    cmp(suppressWarnings(old(w, constraints=cs, weighted=TRUE)),
        suppressWarnings(new(w, constraints=cs, weighted=TRUE)), paste(tag, "| weighted NODF"))
    cmp(suppressWarnings(old(w, constraints=cs, weighted=TRUE, decreasing="abund")),
        suppressWarnings(new(w, constraints=cs, weighted=TRUE, decreasing="abund")), paste(tag, "| WNODA"))
    cmp(suppressWarnings(old(w, constraints=cs, weighted=TRUE, sort=FALSE)),
        suppressWarnings(new(w, constraints=cs, weighted=TRUE, sort=FALSE)), paste(tag, "| weighted, sort=FALSE"))
  } }
cat("\ncomparisons:", tested, " mismatches:", mismatch, "\n")
quit(status = if (mismatch == 0) 0 else 1)
