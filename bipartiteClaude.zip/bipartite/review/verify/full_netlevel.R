.libPaths(c("../lib-before", .libPaths())); suppressMessages(library(bipartite))
set.seed(11); w <- matrix(rpois(40*60, 0.7), 40, 60); w <- w[rowSums(w)>0, colSums(w)>0]
rownames(w) <- paste0("R",1:nrow(w)); colnames(w) <- paste0("C",1:ncol(w))
cat("start\n"); flush.console()
t <- system.time(r <- suppressWarnings(networklevel(w)))[["elapsed"]]
cat("ALLBUTDD:", t, "s, indices:", length(r), "\n")
