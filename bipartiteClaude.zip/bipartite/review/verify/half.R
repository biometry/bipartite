.libPaths(c("../lib-before", .libPaths())); suppressMessages(library(bipartite))
set.seed(11); w <- matrix(rpois(40*60,0.7),40,60); w <- w[rowSums(w)>0, colSums(w)>0]
rownames(w)<-paste0("R",1:nrow(w)); colnames(w)<-paste0("C",1:ncol(w))
ALL <- c("number of species","connectance","web asymmetry","links per species","number of compartments",
"compartment diversity","cluster coefficient","mean number of shared partners","togetherness","C score",
"V ratio","discrepancy","nestedness","NODF","weighted nestedness","spectral radius","ISA","SA",
"extinction slope","robustness","niche overlap","weighted cluster coefficient","modularity","weighted NODF",
"partner diversity","generality","vulnerability","linkage density","weighted connectance","Fisher alpha",
"interaction evenness","Alatalo interaction evenness","Shannon diversity","functional complementarity","H2")
sel <- as.integer(strsplit(commandArgs(TRUE)[1], "-")[[1]])
idx <- ALL[sel[1]:sel[2]]
t <- system.time(suppressWarnings(networklevel(w, index=idx)))[["elapsed"]]
cat(sprintf("indices %2d-%2d : %7.2f s\n", sel[1], sel[2], t))
