# Dump every networklevel / specieslevel index for a set of webs, so before/after can be diffed.
.libPaths(c(commandArgs(TRUE)[1], .libPaths())); suppressMessages(library(bipartite))
out <- list()
webs <- list()
data(Safariland); webs[["Safariland"]] <- as.matrix(Safariland)
data(vazquenc);   webs[["vazquenc"]]   <- as.matrix(vazquenc)
data(memmott1999);webs[["memmott1999"]]<- as.matrix(memmott1999)
set.seed(21); w <- matrix(rpois(15*20,1),15,20); w <- w[rowSums(w)>0,colSums(w)>0]
rownames(w)<-paste0("R",1:nrow(w)); colnames(w)<-paste0("C",1:ncol(w)); webs[["random15x20"]] <- w
for (nm in names(webs)){
  x <- webs[[nm]]
  set.seed(42); nl <- suppressWarnings(networklevel(x, index=setdiff(
     c("number of species","connectance","web asymmetry","links per species","number of compartments",
       "compartment diversity","cluster coefficient","mean number of shared partners","togetherness",
       "C score","V ratio","discrepancy","nestedness","NODF","weighted NODF","spectral radius","ISA","SA",
       "niche overlap","partner diversity","generality","vulnerability","linkage density",
       "weighted connectance","Fisher alpha","interaction evenness","Alatalo interaction evenness",
       "Shannon diversity","functional complementarity","H2"), NULL)))
  set.seed(42); sl <- suppressWarnings(unlist(specieslevel(x, index=c("degree","normalised degree",
       "species strength","PDI","resource range","species specificity","PSI","partner diversity",
       "effective partners","d","proportional generality","proportional similarity"))))
  out[[nm]] <- c(nl, sl)
}
saveRDS(out, commandArgs(TRUE)[2])
cat("wrote", commandArgs(TRUE)[2], "\n")
