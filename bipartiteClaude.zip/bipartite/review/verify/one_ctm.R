.libPaths(c("../lib-before", .libPaths())); suppressMessages(library(bipartite))
a <- commandArgs(TRUE); which <- a[1]; n <- as.integer(a[2]); m <- as.integer(a[3])
src <- if (which=="old") "ctm_old.R" else "../../bipartite/R/clustering_tm.R"
e <- new.env(); sys.source(src, e); f <- e$clustering_tm; environment(f) <- asNamespace("bipartite")
set.seed(11); w <- matrix(rpois(n*m, .7), n, m); w <- w[rowSums(w)>0, colSums(w)>0]
el <- web2edges(w, return=TRUE)
cat(sprintf("%s %dx%d : %.2f s\n", which, nrow(w), ncol(w), system.time(f(el))[["elapsed"]]))
