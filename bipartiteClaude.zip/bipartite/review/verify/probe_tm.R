.libPaths(c("../lib-before", .libPaths())); suppressMessages(library(bipartite))
set.seed(2); w <- matrix(rpois(12*9, 1), 12, 9); w <- w[rowSums(w)>0, colSums(w)>0]
el <- web2edges(w, return=TRUE)
cat("edgelist class:", class(el), " dim:", dim(el), "\n"); print(head(el, 4))
cat("range i:", range(el[,1]), " range p:", range(el[,2]), " web dim:", dim(w), "\n")
net <- bipartite::as.tnet(el, type="weighted two-mode tnet")
cat("tnet attr:", attributes(net)$tnet, " dim:", dim(net), "\n"); print(head(net,4))
cat("\n-- 4-path count growth --\n")
for (n in c(10, 20, 40)) { set.seed(5); x <- matrix(rpois(n*n, .7), n, n); x <- x[rowSums(x)>0, colSums(x)>0]
  e <- web2edges(x, return=TRUE); nt <- bipartite::as.tnet(e, type="weighted two-mode tnet")
  p <- nt; dimnames(p)[[2]] <- c("i1","p1","w1"); dimnames(nt)[[2]] <- c("i2","p1","w2")
  p <- merge(p, nt, sort=FALSE); p <- p[p[,"i1"]!=p[,"i2"],]
  dimnames(nt)[[2]] <- c("i2","p2","w3"); p2 <- merge(p, nt, sort=FALSE); p2 <- p2[p2[,"p1"]!=p2[,"p2"],]
  dimnames(nt)[[2]] <- c("i3","p2","w4"); p3 <- merge(p2, nt, sort=FALSE)
  p3 <- p3[p3[,"i1"]!=p3[,"i3"],]; p3 <- p3[p3[,"i2"]!=p3[,"i3"],]
  cat(sprintf("  %2dx%2d web, %4d edges: 2-paths %7d, 3-paths %8d, 4-paths %9d\n",
      nrow(x), ncol(x), nrow(e), nrow(p), nrow(p2), nrow(p3))) }
