# Asserts the CORRECT behaviour for every bug fixed. Run against either lib:
#   Rscript regression.R ../lib-before   (expect failures)
#   Rscript regression.R ../lib-after    (expect all pass)
.libPaths(c(commandArgs(TRUE)[1], .libPaths())); suppressMessages(library(bipartite))
pass <- 0; fail <- 0
chk <- function(id, desc, expr){
  r <- tryCatch(isTRUE(expr), error=function(e) paste("ERROR:", conditionMessage(e)))
  if (isTRUE(r)) { pass <<- pass+1; cat(sprintf("  PASS  %-4s %s\n", id, desc)) }
  else { fail <<- fail+1; cat(sprintf("  FAIL  %-4s %s %s\n", id, desc, if(is.character(r)) r else "")) } }
data(Safariland); saf <- as.matrix(Safariland)

chk("B1", "shuffle.web preserves sum and connectance", {
  w <- matrix(c(5,0,0, 0,3,0, 7,0,2), 3, byrow=TRUE)
  ok <- TRUE; for (s in 1:25){ set.seed(s); r <- shuffle.web(w,1)[[1]]
    if (sum(r)!=sum(w) || sum(r>0)!=sum(w>0)) ok <- FALSE }; ok })

chk("B2", "extinction(both, degree) actually removes a species", {
  set.seed(1); !identical(unname(extinction(saf, "both", "degree")), unname(saf)) })
chk("B2", "second.extinct(both, degree) terminates", {
  setTimeLimit(elapsed=30, transient=TRUE)
  r <- second.extinct(saf, participant="both", method="degree"); setTimeLimit(); nrow(r) > 1 })

chk("B3", "dfun dmin is 0 when the web already matches expectation", {
  w <- matrix(c(2,2,0, 0,0,8, 2,2,0), 3, byrow=TRUE)
  all(abs(dfun(w)$dmin) < 1e-12) && all(abs(dfun(w)$dprime - c(.5,1,.5)) < 1e-9) })

chk("B4", "togetherness normalises per species pair", {
  set.seed(4); w <- matrix(rbinom(40,1,.5), 8, 5)
  abs(togetherness(w) - 0.3536) < 0.01 })

chk("B5", "ND(normalised=FALSE) is the raw degree", {
  all(ND(saf, normalised=FALSE)$lower == rowSums(saf>0)) })

chk("B6", "networklevel(index='binary') returns C score and shared partners", {
  n <- names(suppressWarnings(networklevel(saf, index="binary")))
  any(grepl("C.score", n)) && any(grepl("shared.partners", n)) })

chk("B7", "nested() rejects an unknown index", {
  inherits(try(nested(saf, c("NODF","bogus-index")), silent=TRUE), "try-error") })

chk("B8", "nullmodel/shuffle.web keeps non-binary values non-binary", {
  w <- matrix(c(0,1.5,0.5, 1.5,0,1.5, 0.5,1.5,0), 3, byrow=TRUE)
  set.seed(1); r <- nullmodel(w, N=1, method="shuffle.web")[[1]]
  !all(r %in% c(0,1)) })

chk("B9", "H2fun H2max is at least the pre-refinement value", {
  set.seed(4); a <- H2fun(saf); a["H2max"] >= 2.3615 })

chk("B10", "nestedness() warns that its arguments are ignored", {
  w <- tryCatch({nestedness(saf, n.nulls=100); FALSE}, warning=function(w) grepl("ignored", conditionMessage(w))); w })

chk("B11", "C.score is finite when a species occupies every site", {
  w <- matrix(c(1,1,1, 1,0,1, 1,1,0), 3, byrow=TRUE)
  is.finite(suppressWarnings(C.score(w))) })

chk("B12", "grouplevel gives a helpful error for a bad level", {
  e <- tryCatch({grouplevel(saf, index="number of species", level="hihger"); ""}, error=function(e) conditionMessage(e))
  grepl("valid level", e) })

chk("B6b","grouplevel warns about an unknown index", {
  tryCatch({grouplevel(saf, index=c("number of species","total nonsense")); FALSE},
           warning=function(w) grepl("not recognised", conditionMessage(w))) })

cat(sprintf("\n  %d passed, %d failed\n", pass, fail))
quit(status = if (fail==0) 0 else 1)
