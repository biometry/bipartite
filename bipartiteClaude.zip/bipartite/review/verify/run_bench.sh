#!/bin/sh
# usage: run_bench.sh <libpath> <outfile.csv>
LIB=$1; OUT=$2
echo "case,seconds" > "$OUT"
for c in cscore:50:40 cscore:50:80 cscore:50:160 \
         smdm_bin:60:60 smdm_bin:120:120 smdm_bin:200:200 \
         smdm_wt:60:60 smdm_wt:120:120 \
         h2fun:40:40 h2fun:80:80 h2fun:120:120 \
         grouplevel:80:80 grouplevel:160:160 \
         secondext:30:30 secondext:50:50 \
         vaznull:40:40 vaznull:80:80 \
         netlevel:40:60 netlevel_saf:0:0 splevel_saf:0:0 ; do
  line=$(ulimit -v 8000000 2>/dev/null; Rscript bench_case.R "$LIB" "$c" 2>/dev/null | tail -1)
  if [ -z "$line" ]; then line="$c,NA"; fi
  echo "$line" | tee -a "$OUT"
done
