.libPaths(c(commandArgs(TRUE)[1], .libPaths())); suppressMessages(library(bipartite))
data(Safariland); w <- as.matrix(Safariland); wb <- (w>0)*1
set.seed(1)
calls <- list(
 "empty"            = quote(empty(w)),
 "C.score"          = quote(C.score(w)),
 "togetherness"     = quote(togetherness(w)),
 "discrepancy"      = quote(discrepancy(w)),
 "nested(ALL)"      = quote(nested(w, "ALL")),
 "nestedness"       = quote(nestedness(w)$statistic),
 "H2fun"            = quote(H2fun(w)),
 "dfun"             = quote(dfun(w)$dprime),
 "ND"               = quote(ND(w)),
 "ND unnorm"        = quote(ND(w, normalised=FALSE)),
 "BC"               = quote(BC(w)),
 "CC"               = quote(CC(w)),
 "PDI"              = quote(PDI(w)),
 "PAC"              = quote(PAC(w)),
 "V.ratio"          = quote(V.ratio(w)),
 "NOS"              = quote(NOS(w)$NOS.lower),
 "nodespec"         = quote(nodespec(w)),
 "compart"          = quote(compart(w)$n.compart),
 "degreedistr"      = quote(degreedistr(w, plot.it=FALSE)),
 "nest.smdm"        = quote(nest.smdm(w)),
 "nest.smdm wt"     = quote(nest.smdm(w, weighted=TRUE)),
 "nestedrank"       = quote(nestedrank(w)),
 "nestedcontribution"=quote(nestedcontribution(w, nsimul=20)),
 "spectral.radius"  = quote(spectral.radius(w)),
 "strength"         = quote(strength(w)),
 "clustering_tm"    = quote(clustering_tm(web2edges(w, return=TRUE))),
 "as.one.mode"      = quote(dim(as.one.mode(w))),
 "web2edges"        = quote(dim(web2edges(w, return=TRUE))),
 "second.extinct L" = quote(second.extinct(w, "lower", "abundance")),
 "second.extinct H" = quote(second.extinct(w, "higher", "degree")),
 "second.extinct B" = quote(second.extinct(w, "both", "degree")),
 "robustness"       = quote(robustness(second.extinct(w, "higher", "abundance"))),
 "slope.bipartite"  = quote(slope.bipartite(second.extinct(w,"higher","abundance"), plot.it=FALSE)),
 "shuffle.web"      = quote(sapply(shuffle.web(w, 5), sum)),
 "vaznull"          = quote(sapply(vaznull(5, w), sum)),
 "swap.web"         = quote(sapply(swap.web(5, w), sum)),
 "mgen"             = quote(sum(mgen(w))),
 "nullmodel r2d"    = quote(sapply(nullmodel(w, N=3, method=1), sum)),
 "nullmodel swap"   = quote(sapply(nullmodel(w, N=3, method=2), sum)),
 "nullmodel vaz"    = quote(sapply(nullmodel(w, N=3, method=3), sum)),
 "nullmodel shuf"   = quote(sapply(nullmodel(wb, N=3, method=4), sum)),
 "nullmodel mgen"   = quote(sapply(nullmodel(w, N=3, method=5), sum)),
 "grouplevel"       = quote(grouplevel(w)),
 "specieslevel"     = quote(unlist(specieslevel(w))),
 "networklevel"     = quote(networklevel(w)),
 "networklevel leg" = quote(networklevel(w, legacy=TRUE)),
 "linklevel"        = quote(dim(linklevel(w))),
 "computeModules"   = quote(round(computeModules(w)@likelihood, 6)),
 "czvalues"         = quote(czvalues(computeModules(w))),
 "wine"             = quote(wine(w, nreps=20)$wine),
 "npartite"         = quote(class(npartite(list(w)))),
 "sortweb"          = quote(dim(sortweb(w))),
 "restrictednull"   = quote(length(restrictednull(w, nreps=2)))
)
res <- list()
for (nm in names(calls)){
  set.seed(7)
  setTimeLimit(elapsed=25, transient=TRUE)
  r <- tryCatch(suppressWarnings(eval(calls[[nm]])), error=function(e) paste("ERROR:", conditionMessage(e)))
  setTimeLimit()
  res[[nm]] <- r
}
saveRDS(res, commandArgs(TRUE)[2]); cat("done\n")
