.libPaths(c("../lib-before", .libPaths())); suppressMessages(library(bipartite))
which <- commandArgs(TRUE)[1]
f <- if (which=="old") { e<-new.env(); sys.source("ctm_old.R", e); environment(e$clustering_tm)<-asNamespace("bipartite"); e$clustering_tm
     } else { e<-new.env(); sys.source("../../bipartite/R/clustering_tm.R", e); environment(e$clustering_tm)<-asNamespace("bipartite"); e$clustering_tm }
for (spec in list(c(20,20), c(30,30), c(40,60))) {
  set.seed(11); w <- matrix(rpois(spec[1]*spec[2], .7), spec[1], spec[2]); w <- w[rowSums(w)>0, colSums(w)>0]
  el <- web2edges(w, return=TRUE)
  gc(reset=TRUE)
  t <- system.time(r <- f(el))[["elapsed"]]
  peak <- sum(gc()[, "max used", drop=TRUE] * c(0.056, 8) / 1e6 * 1e6)  # rough
  cat(sprintf("  %s  %2dx%-2d : %8.2f s   peak Mb reported by gc: %.0f\n",
      which, nrow(w), ncol(w), t, sum(gc()[,6])))
}
