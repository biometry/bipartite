lib <- commandArgs(TRUE)[1]; .libPaths(c(lib, .libPaths())); suppressMessages(library(bipartite))
data(Safariland); w <- as.matrix(Safariland); set.seed(3)
n <- vaznull(200, w)
cat(sprintf("mean sum %.1f | mean links %.2f | target sum %d links %d | all rows>0 %.2f | all cols>0 %.2f | time %.3fs\n",
  mean(sapply(n,sum)), mean(sapply(n,function(x) sum(x>0))), sum(empty(w)), sum(empty(w)>0),
  mean(sapply(n,function(x) all(rowSums(x)>0))), mean(sapply(n,function(x) all(colSums(x)>0))),
  system.time(vaznull(200, w))[["elapsed"]]))
