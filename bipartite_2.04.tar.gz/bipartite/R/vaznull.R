vaznull <- function(N, web){
  # This function produces a null model network with two constraints:
  # a) marginal totals are the same as in the original network (see also r2dtable)
  # b) connectance is the same as in the original network.
  # vaznull differs from swap.web both in the algorithm used as well as in the
  # null model it outputs.
  # vaznull is our implementation of the algorithm propose by Diego V·zquez, hence its name.
  # While vaznull is slower than swap.web, we regard it as better.
  #
  # implementor: Bernd Gruber <bernd.gruber@ufz.de> & Carsten Dormann

  web <- as.matrix(empty(web)) # otherwise we cannot compute the crossproduct later on. 

# brute force:
finalmat <- web
finalmat[,] <- 0
i=1
while (i < sum(web)){ # for each interaction
	for (j in 1:nrow(web)){ # go through each row
		for (k in 1:ncol(web)){ # and each cell
			finalmat2 <- finalmat
			finalmat2[j,k] <- finalmat2[j,k] + 1
			if (sum(finalmat > 0)/prod(dim(finalmat)) <= sum(web > 0)/prod(dim(web)) & any(rowSums(finalmat) <= rowSums(web))  &  any(colSums(finalmat) <= colSums(web))){
				 finalmat <- finalmat2
				 i <- i + 1
			}
		}
	}
}

  vaznull.fast <- function(web){
  
   rs.p <- rowSums(web)/sum(web)
   cs.p <- colSums(web)/sum(web)
   P <- P1 <- tcrossprod(rs.p, cs.p)
   
   int.remain <- sum(web)
   while (int.remain > 0){
     #create only one new mat
     finalmat <- matrix(0, nrow(web), ncol(web))
     # finalmat <- newmat
     # set up SKELETON: go through this loop until all dimensions are attained
     n.int.finalmat <- 0
     while (n.int.finalmat < sum(dim(web))){
       # randomly select a cell, according to probability matrix P:
       sel <- sample(1:length(web), 1,  prob=P, replace=TRUE)
       #convert sel into coordinates
       selc <- floor((sel-1)/(dim(web)[1])) + 1
       selr <- ((sel-1) %% dim(web)[1]) + 1
       #check if row or column is still free?
       if ( sum(finalmat[,selc]) == 0 | sum(finalmat[selr,]) == 0 ){
         finalmat[sel] <- 1
         P[sel] <- 0
       }
       #if yes update finalmat, if not try again
       n.int.finalmat <- sum(rowSums(finalmat) > 0) + sum(colSums(finalmat) > 0) # computes sum of filled "dimensions"
     }
     # Step 2. IV: fill up to full connectance:
     conn.remain <- sum(web > 0) - sum(finalmat > 0)
     if (conn.remain > 0) {
       add <- sample(which(finalmat == 0), conn.remain, prob=P1[finalmat == 0])
       finalmat[add] <- 1
     }
     
     ## sanity check: if already row/column marginals are violated, start over:
     if (sum(finalmat > 0)/prod(dim(finalmat)) > sum(web > 0)/prod(dim(web)) | any(rowSums(finalmat) > rowSums(web))  |  any(colSums(finalmat) > colSums(web))) next #else print(finalmat)
     
     # FILL INTERACTIONS
     int.remain <- int.remain.initial <- sum(web) - sum(finalmat)
     i = 1
     # add one interaction at a time, obeying row and column constraints:
     while (int.remain > 0 & i < (int.remain.initial +1)){
       row.options <- which(rowSums(finalmat) < rowSums(web))
       col.options <- which(colSums(finalmat) < colSums(web))
	  	 
       putting.options <- which(finalmat >= 0, arr.ind=TRUE)
       real.options <- which(putting.options[,1] %in% row.options & putting.options[,2] %in% col.options)
       add <- sample(real.options, length(real.options))        
              
       finalmat2 <- finalmat
       finalmat2[putting.options[add[1], 1], putting.options[add[1], 2]] <- finalmat2[putting.options[add[1], 1], putting.options[add[1], 2]] + 1
	   if (all(rowSums(finalmat2) <= rowSums(web)) & all(colSums(finalmat2) <= colSums(web)) & sum(finalmat > 0)/prod(dim(finalmat)) > sum(web > 0)/prod(dim(web))){
	  	  finalmat <- finalmat2
	  	  int.remain <- sum(web) - sum(finalmat)
	  	  print("a successful filling")
	   } else {print("an unsuccessful filling"); break} # need to get out of the inner while loop!
	   # else { # try once more with the next option:
	  	#  add <- add[-which(add == add[1])] 
	  	#  if (length(add) == 0) add <- sample(which(finalmat[row.options, col.options] >= 0), 100, prob=P1[which(finalmat[row.options, col.options] >= 0)], replace=TRUE)
	  	#   finalmat2[add[1]] <- finalmat2[add[1]] + 1
	  	#   if (all(rowSums(finalmat2) <= rowSums(web)) & all(colSums(finalmat2) <= colSums(web))){
	  	#	   finalmat <- finalmat2
	  	#   }
	  	#   i=i+1
	  	#   int.remain <- sum(web) - sum(finalmat)
	  	# }
	  	# cat(i, " ")
	   #}
     
    # now CHECK results:
    if (sum(finalmat > 0)/prod(dim(finalmat)) == sum(web > 0)/prod(dim(web)) & all(rowSums(finalmat) == rowSums(web))  &  all(colSums(finalmat) == colSums(web))) print("done!") else print("added a point");
    }
   
	finalmat
  }

  # vectorised call of vaznull.fast:
  replicate(N, vaznull.fast(web), simplify=FALSE)

}
#data(Safariland)
#vaznull(1, Safariland)
#system.time(vaznull(10, Safariland))
#system.time(swap.web(10, Safariland))