###
# @author: Tobias Bauer

# Generics ------------------------------------------------
# Access and replacement functions are S3 generics
higher_attributes <- function(x, web_id = NULL) {
  UseMethod("higher_attributes")
}
`higher_attributes<-` <- function(x, web_id = NULL, value) {
  UseMethod("higher_attributes<-")
}


lower_attributes <- function(x, web_id = NULL) {
  UseMethod("lower_attributes")
}
`lower_attributes<-` <- function(x, web_id = NULL, value) {
  UseMethod("lower_attributes<-")
}

meta_attributes <- function(x, web_id = NULL) {
  UseMethod("meta_attributes")
}
`meta_attributes<-` <- function(x, web_id = NULL, value) {
  UseMethod("meta_attributes<-")
}

# Base class bipartite_web --------------------------------
## Basic constructor --------------------------------------
bipartite_web <- function(web,
                          higher_attributes = NULL,
                          lower_attributes = NULL,
                          meta_attributes = list()) {
  # Validate the underlying object
  if (!is.matrix(web)) {
    web <- as.matrix(web)
  }

  if (is.null(rownames(web))) {
    rownames(web) <- paste0("row", seq_len(nrow(web)))
  }
  if (is.null(colnames(web))) {
    colnames(web) <- paste0("col", seq_len(ncol(web)))
  }

  # Default metadata
  if (is.null(lower_attributes)) {
    lower_attributes <- data.frame(
      row.names = rownames(web)
    )
  }

  if (is.null(higher_attributes)) {
    higher_attributes <- data.frame(
      row.names = colnames(web)
    )
  }

  # Validate metadata dimensions
  if (!is.data.frame(lower_attributes) || nrow(lower_attributes) != nrow(web)) {
    stop("`lower_attributes` must be a data frame with one row per matrix row.")
  }

  if (!is.data.frame(higher_attributes) || nrow(higher_attributes) != ncol(web)) {
    stop("`higher_attributes` must be a data frame with one row per matrix column.")
  }

  if (!is.list(meta_attributes)) {
    stop("`meta_attributes` must be a list.")
  }

  structure(
    web,
    lower_attributes = lower_attributes,
    higher_attributes = higher_attributes,
    meta_attributes = meta_attributes,
    class = c("bipartite_web", "matrix", "array")
  )
}

as.bipartite_web <- function(x) {
  UseMethod("as.bipartite_web")
}

as.bipartite_web.default <- function(x) {
  bipartite_web(as.matrix(x))
}

as.bipartite_web.bipartite_web <- function(x) {
  x
}

as.bipartite_web.matrix <- function(x) {
  bipartite_web(x)
}

as.bipartite_web.data.frame <- function(x) {
  bipartite_web(as.matrix(x))
}

as.matrix.bipartite_web <- function(x, ...) {
  nc <- ncol(x)
  nr <- nrow(x)
  dnames <- dimnames(x)
  matrix(x, nr, nc, dimnames = dnames)
}

## Subsetting ---------------------------------------------
`[.bipartite_web` <- function(x, i, j, drop = TRUE) {

  # Subset the actual matrix
  y <- NextMethod("[", drop = drop)

  # If dimensions have been dropped, we no longer have
  # a my_matrix in the intended sense.
  if (drop && !is.matrix(y)) {
    return(y)
  }

  lower_attributes <- attr(x, "lower_attributes")
  higher_attributes <- attr(x, "higher_attributes")
  meta_attributes <- attr(x, "meta_attributes")

  if (!missing(i)) {
    lower_attributes <- lower_attributes[i, , drop = FALSE]
  }

  if (!missing(j)) {
    higher_attributes <- higher_attributes[j, , drop = FALSE]
  }

  bipartite_web(
    y,
    lower_attributes = lower_attributes,
    higher_attributes = higher_attributes,
    meta_attributes = meta_attributes
  )
}

## Transposing --------------------------------------------
t.bipartite_web <- function(x) {
  y <- NextMethod("t")
  bipartite_web(
    y,
    higher_attributes = lower_attributes(x),
    lower_attributes =  higher_attributes(x),
    meta_attributes = meta_attributes(x)
  )
}

## Access functions ---------------------------------------

higher_attributes.bipartite_web <- function(x, web_id) {
  attr(x, "higher_attributes")
}

lower_attributes.bipartite_web <- function(x, web_id) {
  attr(x, "lower_attributes")
}

meta_attributes.bipartite_web <- function(x, web_id) {
  attr(x, "meta_attributes")
}

## Replacement functions ----------------------------------
`higher_attributes<-.bipartite_web` <- function(x, web_id, value) {
  if (!is.data.frame(value)) {
    stop("`higher_attributes` must be a data frame.")
  }

  if (nrow(value) != ncol(x)) {
    stop("`higher_attributes` must have one row per matrix column")
  }

  attr(x, "higher_attributes") <- value
  x
}

`lower_attributes<-.bipartite_web` <- function(x, web_id, value) {
  if (!is.data.frame(value)) {
    stop("`lower_attributes` must be a data frame.")
  }

  if (nrow(value) != nrow(x)) {
    stop("`lower_attributes` must have one row per matrix row")
  }

  attr(x, "lower_attributes") <- value
  x
}

`meta_attributes<-.bipartite_web` <- function(x, web_id, value) {
  if (!is.list(value)) {
    stop("`meta_attributes` must be a list.")
  }

  attr(x, "meta_attributes") <- value
  x
}

## Print function -----------------------------------------
print.bipartite_web <- function(x, ...) {
  cat("<bipartite_web object>\n")
  cat("Dimensions:", nrow(x), "x", ncol(x), "\n")
  cat(strrep("-", 50), "\n")
  cat("Higher species attributes:\n")
  print(higher_attributes(x), ...)
  cat("Lower species attributes:\n")
  print(lower_attributes(x), ...)
  cat("Meta attributes:\n")
  print(meta_attributes(x), ...)
  cat(strrep("-", 50), "\n")
  cat("Matrix:\n")
  print(matrix(x,
               nrow = nrow(x),
               ncol = ncol(x),
               dimnames = list(rownames(x), colnames(x))), ...)
}

# bipartite_webarray class --------------------------------
## Wide approach ------------------------------------------
## Separate data.frame for each web and each level.
## So w * h + w * l local data.frames in total.
## Additonally one global data.frame for higher and lower each.
## TODO: Add constructor for list of bipartite_web objects
## TODO: Maybe make all constructors generics?
bipartite_webarray <- function(webs, ...,
                               global_higher_attributes = NULL,
                               global_lower_attributes = NULL,
                               local_higher_attributes = NULL,
                               local_lower_attributes = NULL,
                               global_meta_attributes = NULL,
                               local_meta_attributes = NULL) {
  # Combining the matrix inputs into a 3D-array
  if (is.array(webs) && length(dim(webs)) == 3) {
    warray <- webs
    web_names <- dimnames(warray)[[3]]
    if (is.null(web_names)) {
      web_names <- paste0("web", seq_along(webs))
    }
  } else {
    # Reused code from web2array by Carsten and Jochen
    if (is(webs, "list")) {
      web_names <- names(webs)
      if (is.null(web_names)) {
        web_names <- paste0("web", seq_along(webs))
      }
    } else {
      # combine all ... and x into a single list:
      webinput <- substitute(list(webs, ...))
      web_names <- as.character(webinput)[-1L]
      webs <- eval(webinput)
    }

    if (length(webs) < 2) stop("Please provide more than one web as input!")
    all.names.HL <- sort(unique(unlist(lapply(webs, colnames))))
    all.names.LL <- sort(unique(unlist(lapply(webs, rownames))))
    warray <- array(0,
                    dim = c(length(all.names.LL),
                            length(all.names.HL),
                            length(web_names)),
                    dimnames = list(all.names.LL, all.names.HL, web_names))
    for (i in seq_along(web_names)){
      ri <- rownames(webs[[i]])
      ci <- colnames(webs[[i]])
      warray[ri, ci, i] <- webs[[i]]
    }
  }
  # Default attributes
  if (is.null(global_higher_attributes)) {
    global_higher_attributes <- data.frame(
      row.names = colnames(warray)
    )
  } else {
    stopifnot(is.data.frame(global_higher_attributes))
    ## Select the rows in the same order as the columns of warray
    global_higher_attributes <- global_higher_attributes[colnames(warray), , drop = FALSE]
    ## Reset names in case of missing rows
    rownames(global_higher_attributes) <- colnames(warray)
  }
  if (is.null(global_lower_attributes)) {
    global_lower_attributes <- data.frame(
      row.names = rownames(warray)
    )
  } else {
    stopifnot(is.data.frame(global_lower_attributes))
    global_lower_attributes <- global_lower_attributes[rownames(warray), , drop = FALSE]
    rownames(global_lower_attributes) <- rownames(warray)
  }
  if (is.null(local_higher_attributes)) {
    local_higher_attributes <- list()
    for (name in web_names) {
      local_higher_attributes[[name]] <- data.frame(
        row.names = colnames(warray)
      )
    }
  } else {
    stopifnot(is.list(local_higher_attributes))
    for (name in web_names) {
      ## If a webname is missing or no data.frame was given,
      ## create an empty data.frame
      if (is.null(local_higher_attributes[[name]])) {
        local_higher_attributes[[name]] <- data.frame(
          row.names = colnames(warray)
        )
      } else {
        local_h_df <- local_higher_attributes[[name]]
        if (!is.data.frame(local_h_df)) {
          stop("Element ", name, " in local_higher_attributes is not a data.frame.")
        }
        local_higher_attributes[[name]] <- local_h_df[colnames(warray), , drop = FALSE]
        rownames(local_higher_attributes[[name]]) <- colnames(warray)
      }
    }
    ## Filter out list elements that don't have a matching web_name
    local_higher_attributes <- local_higher_attributes[web_names]
  }
  if (is.null(local_lower_attributes)) {
    local_lower_attributes <- list()
    for (name in web_names) {
      local_lower_attributes[[name]] <- data.frame(
        row.names = rownames(warray)
      )
    }
  } else {
    stopifnot(is.list(local_lower_attributes))
    for (name in web_names) {
      ## If a webname is missing or no data.frame was given,
      ## create an empty data.frame
      if (is.null(local_lower_attributes[[name]])) {
        local_lower_attributes[[name]] <- data.frame(
          row.names = rownames(warray)
        )
      } else {
        local_l_df <- local_lower_attributes[[name]]
        if (!is.data.frame(local_l_df)) {
          stop("Element ", name, " in local_lower_attributes is not a data.frame.")
        }
        local_lower_attributes[[name]] <- local_l_df[rownames(warray), , drop = FALSE]
        rownames(local_lower_attributes[[name]]) <- rownames(warray)
      }
    }
    ## Filter out list elements that don't have a matching web_name
    local_lower_attributes <- local_lower_attributes[web_names]
  }
  if (is.null(global_meta_attributes)) {
    global_meta_attributes <- list()
  } else {
    stopifnot(is.list(global_meta_attributes))
  }
  if (is.null(local_meta_attributes)) {
    local_meta_attributes <- list()
    for (name in web_names) {
      local_meta_attributes[[name]] <- list()
    }
  } else {
    stopifnot(is.list(local_meta_attributes))
    for (name in web_names) {
      ## If a webname is missing create an empty list
      if (is.null(local_meta_attributes[[name]])) {
        local_meta_attributes[[name]] <- list()
      }
    }
    ## Filter out list elements that don't have a matching web_name
    local_meta_attributes <- local_meta_attributes[web_names]
  }
  structure(
    warray,
    global_higher_attributes = global_higher_attributes,
    global_lower_attributes  = global_lower_attributes,
    local_higher_attributes  = local_higher_attributes,
    local_lower_attributes   = local_lower_attributes,
    global_meta_attributes   = global_meta_attributes,
    local_meta_attributes    = local_meta_attributes,
    class                    = c("bipartite_webarray", "array")
  )
}

### Access functions --------------------------------------
higher_attributes.bipartite_webarray <- function(x, web_id = NULL) {
  if (is.null(web_id)) {
    return(attr(x, "global_higher_attributes"))
  }  else if (!web_id %in% dimnames(x)[[3]] && !web_id %in% seq_len(dim(x)[[3]])) {
    stop("Index ", web_id, " not in ", as.character(substitute(x)), ".")
  } else {
    local_attrs <- attr(x, "local_higher_attributes")
    return(local_attrs[[web_id]])
  }
}

lower_attributes.bipartite_webarray <- function(x, web_id = NULL) {
  if (is.null(web_id)) {
    return(attr(x, "global_lower_attributes"))
  }  else if (!web_id %in% dimnames(x)[[3]] && !web_id %in% seq_len(dim(x)[[3]])) {
    stop("Index ", web_id, " not in ", as.character(substitute(x)), ".")
  } else {
    local_attrs <- attr(x, "local_lower_attributes")
    return(local_attrs[[web_id]])
  }
}

meta_attributes.bipartite_webarray <- function(x, web_id = NULL) {
  if (is.null(web_id)) {
    return(attr(x, "global_meta_attributes"))
  }  else if (!web_id %in% dimnames(x)[[3]] && !web_id %in% seq_len(dim(x)[[3]])) {
    stop("Index ", web_id, " not in ", as.character(substitute(x)), ".")
  } else {
    local_attrs <- attr(x, "local_meta_attributes")
    return(local_attrs[[web_id]])
  }
}

### Replacement functions ---------------------------------
`higher_attributes<-.bipartite_webarray` <- function(x, web_id = NULL, value) {
  if (!is.data.frame(value)) {
    stop("`higher_attributes` must be a data frame.")
  }

  if (nrow(value) != ncol(x)) {
    stop("`higher_attributes` must have one row per matrix column")
  }

  if (is.null(web_id)) {
    attr(x, "global_higher_attributes") <- value
  } else if (!web_id %in% dimnames(x)[[3]] && !web_id %in% seq_len(dim(x)[[3]])) {
    stop("Index ", web_id, " not in ", as.character(substitute(x)), ".")
  } else {
    attr(x, "local_higher_attributes")[[web_id]] <- value
  }
  x
}

`lower_attributes<-.bipartite_webarray` <- function(x, web_id = NULL, value) {
  if (!is.data.frame(value)) {
    stop("`lower_attributes` must be a data frame.")
  }

  if (nrow(value) != ncol(x)) {
    stop("`lower_attributes` must have one row per matrix column")
  }

  if (is.null(web_id)) {
    attr(x, "global_lower_attributes") <- value
  } else if (!web_id %in% dimnames(x)[[3]] && !web_id %in% seq_len(dim(x)[[3]])) {
    stop("Index ", web_id, " not in ", as.character(substitute(x)), ".")
  } else {
    attr(x, "local_lower_attributes")[[web_id]] <- value
  }
  x
}

`meta_attributes<-.bipartite_webarray` <- function(x, web_id = NULL, value) {
  if (!is.list(value)) {
    stop("`meta_attributes` must be a list.")
  }

  if (is.null(web_id)) {
    attr(x, "global_meta_attributes") <- value
  } else if (!web_id %in% dimnames(x)[[3]] && !web_id %in% seq_len(dim(x)[[3]])) {
    stop("Index ", web_id, " not in ", as.character(substitute(x)), ".")
  } else {
    attr(x, "local_meta_attributes")[[web_id]] <- value
  }
  x
}

### Subsetting ---------------------------------------------
`[.bipartite_webarray` <- function(x, i, j, k, drop = TRUE) {
  # Subset the actual array
  y <- NextMethod("[", drop = drop)
  if (!is.array(y)) {
    return(y)
  } else if (length(dim(y)) < 3) {
    if (missing(k) || length(k) != 1) {
      return(y)
    }
  }

  global_higher_attributes <- attr(x, "global_higher_attributes")
  local_higher_attributes  <- attr(x, "local_higher_attributes")
  global_lower_attributes  <- attr(x, "global_lower_attributes")
  local_lower_attributes   <- attr(x, "local_lower_attributes")
  global_meta_attributes   <- attr(x, "global_meta_attributes")
  local_meta_attributes    <- attr(x, "local_meta_attributes")

  if (!missing(k)) {
    local_higher_attributes <- local_higher_attributes[k]
    local_lower_attributes  <- local_lower_attributes[k]
    local_meta_attributes   <- local_meta_attributes[k]
    web_indices <- k
  } else {
    web_indices <- dimnames(y)[[3]]
  }

  if (!missing(i)) {
    global_lower_attributes <- global_lower_attributes[i, , drop = FALSE]
    for (web in web_indices) {
      local_lower_attributes[[web]]  <- local_lower_attributes[[web]][i, , drop = FALSE]
    }
  }

  if (!missing(j)) {
    global_higher_attributes <- global_higher_attributes[j, , drop = FALSE]
    for (web in web_indices) {
      local_higher_attributes[[web]]  <- local_higher_attributes[[web]][j, , drop = FALSE]
    }
  }
  ## If k has 1 element only 1 web remains.
  ## Return that web as a bipartite_web object instead of an array.
  if (!missing(k) && length(k) == 1) {
    higher_attributes <- cbind(global_higher_attributes, local_higher_attributes)
    lower_attributes  <- cbind(global_lower_attributes, local_lower_attributes)
    if (length(dim(y)) == 3) {
      ## For the rare case where drop = TRUE and only one web is selected,
      ## we need to selectevly drop the 3rd dimension of the array for the
      ## as.matrix() call inside bipartite_web to work.
      y = array(y, dim = dim(y)[-3], dimnames = dimnames(y)[-3])
    }
    meta_attributes   <- c(global_meta_attributes, local_meta_attributes)
    z <- bipartite_web(
      y,
      higher_attributes = higher_attributes,
      lower_attributes  = lower_attributes,
      meta_attributes   = meta_attributes
    )
    return(z)
  }

  bipartite_webarray(
    y,
    global_higher_attributes = global_higher_attributes,
    global_lower_attributes  = global_lower_attributes,
    local_higher_attributes  = local_higher_attributes,
    local_lower_attributes   = local_lower_attributes,
    global_meta_attributes   = global_meta_attributes,
    local_meta_attributes    = local_meta_attributes
  )
}

### Print -------------------------------------------------
print.bipartite_webarray <- function(x, ...) {
  cat("<bipartite_webarray object>\n")
  cat("Dimensions:", dim(x)[1L], "x", dim(x)[2L], "x", dim(x) [3L], "\n")
  web_names <- dimnames(x)[[3]]
  cat("Web names:", web_names, "\n")
  cat(strrep("-", 50), "\n")
  cat("Global higher attributes:\n")
  print(higher_attributes(x))
  cat("Global lower attributes:\n")
  print(lower_attributes(x))
  cat("Global meta attributes:\n")
  print(meta_attributes(x))
  nr <- nrow(x)
  nc <- ncol(x)
  for (web in web_names) {
    cat(strrep("-", 50), "\n")
    cat(web, "\n")
    cat("Higher attributes:\n")
    print(higher_attributes(x, web))
    cat("Lower attributes:\n")
    print(lower_attributes(x, web))
    cat("Meta attributes:\n")
    print(meta_attributes(x, web))
    cat("Matrix:\n")
    web_data <- x[, , web]
    web_matrix <- matrix(web_data,
                         nrow = nr,
                         ncol = nc,
                         dimnames = dimnames(web_data))
    print(web_matrix)
  }
}

# warray <- bipartite_webarray(Safariland, vazarr)
# higher_attributes(warray)$rand <- runif(41)
# higher_attributes(warray, "Safariland")$rand <- runif(41)
# warray[1:3, 3:5, "Safariland"]
# print(warray)
# web_names <- dimnames(warray)[[3]]
# web_names
