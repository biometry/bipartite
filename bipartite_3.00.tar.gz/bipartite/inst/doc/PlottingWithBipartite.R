## ----echo = FALSE, message = FALSE--------------------------------------------
options(max.print = 10)
library(bipartite)

## ----new_safariland-----------------------------------------------------------
plot(Safariland)

## -----------------------------------------------------------------------------
web <- bipartite_web(matrix(c(50, 50), ncol = 2))
plot(web, plot_axes = TRUE)

## -----------------------------------------------------------------------------
plot(web, spacing = 0.1, plot_axes = TRUE)

## -----------------------------------------------------------------------------
plot(web, spacing = 0.1, text_size = 2)

## ----fig.height=6, fig.width=6------------------------------------------------
plot(Safariland, spacing = "auto", text_size = 0.75)

## ----web_horizontal-----------------------------------------------------------
web <- bipartite_web(genweb(5, 6))
plot(web, horizontal = TRUE)

## ----sorting_reverse----------------------------------------------------------
plot(web[rev(rownames(web)), ], horizontal = TRUE)

## ----sorting_all--------------------------------------------------------------
plot(Safariland, horizontal = TRUE, sorting = "dec")
plot(Safariland, horizontal = TRUE, sorting = "inc")
plot(Safariland, horizontal = TRUE, sorting = "ca")

## -----------------------------------------------------------------------------
load("Safariland.web.RData")
Safariland.web

## -----------------------------------------------------------------------------
lower_attributes(Safariland.web)$l_abuns <- sample(0:100,
                                                   nrow(Safariland.web),
                                                   replace = TRUE)
options(max.print = 100)
lower_attributes(Safariland.web)

## -----------------------------------------------------------------------------
plot(Safariland.web, sorting = "ca", horizontal = TRUE,
     lower_abundances = "l_abuns")

## -----------------------------------------------------------------------------
plot(Safariland.web, sorting = "ca", horizontal = TRUE,
     add_lower_abundances = "l_abuns")

## -----------------------------------------------------------------------------
higher_attributes(Safariland.web)$h_abuns <- sample(0:1000,
                                                    ncol(Safariland.web),
                                                    replace = TRUE)
plot(Safariland.web, sorting = "ca", horizontal = TRUE,
     higher_abundances = "h_abuns", scaling = "relative")
plot(Safariland.web, sorting = "ca", horizontal = TRUE,
     higher_abundances = "h_abuns", scaling = "absolute")

## -----------------------------------------------------------------------------
plot(Safariland.web, sorting = "ca", horizontal = TRUE,
     add_lower_abundances = "l_abuns", scaling = "absolute")

## -----------------------------------------------------------------------------
plot(Safariland, curved_links = TRUE)

## -----------------------------------------------------------------------------
plot(Safariland, horizontal = TRUE, curved_links = TRUE)

## -----------------------------------------------------------------------------
plot(Safariland, sorting = "ca", horizontal = TRUE, curved_links = TRUE,
     higher_italic = TRUE, lower_italic = TRUE)

## -----------------------------------------------------------------------------
higher_labels <- colnames(Safariland)
names(higher_labels) <- higher_labels
species_name_selector <- lengths(strsplit(higher_labels, " ")) == 2
higher_species_names <- higher_labels[species_name_selector]
higher_labels[higher_species_names] <- lapply(higher_species_names,
                                              function(x) bquote(italic(.(x))))

plot(Safariland, sorting = "ca", horizontal = TRUE, curved_links = TRUE,
     higher_labels = higher_labels, lower_italic = TRUE)

## -----------------------------------------------------------------------------
plot(Safariland, sorting = "ca", horizontal = TRUE, curved_links = TRUE,
     higher_labels = higher_labels, lower_italic = TRUE,
     higher_color = "orange", lower_color = "darkgreen")


## -----------------------------------------------------------------------------
plot(Safariland, sorting = "ca", horizontal = TRUE, curved_links = TRUE,
     higher_labels = higher_labels, lower_italic = TRUE,
     lower_color = rainbow(nrow(Safariland)))

## -----------------------------------------------------------------------------
plot(Safariland.web, sorting = "ca", horizontal = TRUE, curved_links = TRUE,
     higher_labels = higher_labels, lower_italic = TRUE,
     lower_color = c("Native" = "black", "Exotic" = "orange"),
     lower_color_attr = "Origin")


## -----------------------------------------------------------------------------
plot(Safariland.web, sorting = "ca", horizontal = TRUE, curved_links = TRUE,
     higher_labels = higher_labels, lower_italic = TRUE,
     lower_color = c("Native" = "black", "Exotic" = "orange"),
     lower_color_attr = "Origin", link_color = "lower")

## -----------------------------------------------------------------------------
plot(Safariland, sorting = "ca", horizontal = TRUE, curved_links = TRUE,
     higher_labels = higher_labels, lower_italic = TRUE,
     higher_color = "orange", lower_color = "darkgreen",
     link_color = "brown")

## -----------------------------------------------------------------------------
plot(Safariland.web, sorting = "ca", horizontal = TRUE,
     add_lower_abundances = "l_abuns", curved_links = TRUE,
     higher_labels = higher_labels, higher_color = "grey50",
     lower_italic = TRUE,
     lower_color_attr = "Origin",
     lower_color = c("Native" = "black", "Exotic" = "orange"),
     link_color = "lower",
     lower_add_color = c("Native" = "black", "Exotic" = "darkorange"))

## -----------------------------------------------------------------------------
plot(Safariland.web, sorting = "ca", horizontal = TRUE,
     add_lower_abundances = "l_abuns",
     curved_links = TRUE, higher_labels = higher_labels,
     higher_color = "grey50", lower_italic = TRUE,
     lower_color_attr = "Life.form",
     lower_color = c("Understory tree" = "brown3",
                     "Herb" = "bisque",
                     "Shrub" = "darkolivegreen3",
                     "Vine" = "darkorange"),
     link_color = "lower", link_alpha = 1, higher_border = "black",
     link_border = "black", lower_border = "black",
     lower_add_color = c("Understory tree" = "brown4",
                         "Herb" = "bisque3",
                         "Shrub" = "darkolivegreen4",
                         "Vine" = "darkorange3"))

## -----------------------------------------------------------------------------
webs <- bipartite_webarray(Safariland, vazarr)
plot(webs)

## -----------------------------------------------------------------------------
plot(webs, web1 = "vazarr", web2 = "Safariland", horizontal = TRUE,
     higher_color = "red", higher_border = FALSE)

