## ----results = "hide", message = FALSE, cache = FALSE-------------------------
library(bipartite)
data(Safariland)
options(max.print = 10)

## -----------------------------------------------------------------------------
class(Safariland)

## -----------------------------------------------------------------------------
str(Safariland)

## -----------------------------------------------------------------------------
plant_attributes <- read.csv("plant_attributes.csv", row.names = 1)
plant_attributes <- plant_attributes[rownames(Safariland), ]
plant_attributes

## -----------------------------------------------------------------------------
pollinator_attributes <- read.csv("pollinator_attributes.csv", row.names = 1)
pollinator_attributes <- pollinator_attributes[colnames(Safariland), ]
pollinator_attributes

## -----------------------------------------------------------------------------
Safariland.web <- bipartite_web(Safariland,
                                lower_attributes = plant_attributes,
                                higher_attributes = pollinator_attributes,
                                meta_attributes = list("type" = "pollination"))
print(Safariland.web)

## ----eval = FALSE-------------------------------------------------------------
# save(Safariland.web, file = "Safariland.web.RData")

## -----------------------------------------------------------------------------
dim(Safariland)
dim(vazarr)

## -----------------------------------------------------------------------------
warray <- bipartite_webarray(Safariland, vazarr)
dim(warray)

## -----------------------------------------------------------------------------
print(warray)

## -----------------------------------------------------------------------------
pollinator_attributes <- read.csv("pollinator_attributes.csv", row.names = 1)
plant_attributes <- read.csv("plant_attributes.csv", row.names = 1)

## -----------------------------------------------------------------------------
vazarr_higher_attributes <- data.frame(id = 1:ncol(vazarr),
                                       row.names = colnames(vazarr))
safariland_lower_attributes <- data.frame(id = 1:nrow(Safariland),
                                          row.names = rownames(Safariland))
warray <- bipartite_webarray(Safariland, vazarr,
                             global_higher_attributes = pollinator_attributes,
                             global_lower_attributes = plant_attributes,
                             global_meta_attributes = list(type = "pollinaton"),
                             local_higher_attributes = list("vazarr" = vazarr_higher_attributes),
                             local_lower_attributes = list("Safariland" = safariland_lower_attributes))
warray

## -----------------------------------------------------------------------------
higher_attributes(Safariland.web)
lower_attributes(Safariland.web)
meta_attributes(Safariland.web)

## -----------------------------------------------------------------------------
higher_attributes(Safariland.web)$Order
higher_attributes(Safariland.web)["Ruizantheda proxima", ]

## -----------------------------------------------------------------------------
higher_attributes(warray)

## -----------------------------------------------------------------------------
higher_attributes(warray, web_id = "vazarr")

## -----------------------------------------------------------------------------
meta_attributes(Safariland.web)$start_year <- 1999
meta_attributes(Safariland.web)$end_year <- 2000
meta_attributes(Safariland.web)

## ----max.print = 50-----------------------------------------------------------
higher_attributes(Safariland.web)$id <- 1:ncol(Safariland.web)
higher_attributes(Safariland.web)

## -----------------------------------------------------------------------------
Safariland.web[1:5, 1:3]

## -----------------------------------------------------------------------------
Safariland.web[1:5, 1]
Safariland.web[5, 3]

## -----------------------------------------------------------------------------
Safariland.web[1:5, 1, drop = FALSE]
Safariland.web[5, 3, drop = FALSE]

## -----------------------------------------------------------------------------
Safariland.web["Rosa eglanteria", "Ruizantheda mutabilis", drop = FALSE]

## -----------------------------------------------------------------------------
warray[, , "vazarr"]

